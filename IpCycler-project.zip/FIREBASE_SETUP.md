# IP Cycler Firebase setup

This build uses the existing Firebase Realtime Database project `kheloff-72149`.

## 1. Enable Anonymous Authentication
Firebase Console -> Authentication -> Sign-in method -> Anonymous -> Enable.

## 2. Create the initial global config
Realtime Database -> Data -> create:

config
  enabled: true

Keep `enabled` false if you want every client locked until the admin is ready.

## 3. Apply database rules
Use the contents of `database.rules.json` in Realtime Database -> Rules, then Publish.

The app can only create its own device record once, with status `pending`. It can never modify it afterwards, so a client cannot approve itself.

The administrator changes device status from the Firebase Console or a future admin panel.

## 4. Approve a device
After the APK is installed and opened once, a new device creates:

`devices/<anonymous-auth-uid>`

with only:
- `status: pending`
- `uid`

(No createdAt / lastSeen / appVersion any more, so the values never change by themselves.)

Change that device's `status` to `approved` in the Firebase Console.

## 5. Disable a device
Change its status to `disabled`.

## 6. Global kill switch
Change `config/enabled` to `false` to disable the IP Cycler for all devices. Set it back to `true` to enable it again.

The app fails closed: if authorization cannot be confirmed, START is disabled.

## Offline access (7 days)
After the server has approved a device, the app remembers that on the phone and keeps working with no internet for 7 days (`AuthManager.OFFLINE_GRACE_DAYS`). Every time the phone is online and still approved, the 7 days start again. After that, START is blocked until the phone connects once and the server confirms again. If the server says disabled/rejected (or the global switch is off), the offline approval is erased immediately.

The age is measured with the phone's monotonic clock (not the date/time setting), so changing the date/time does not extend it. The screen does not show how much time is left.

## Internet test
The main screen has a checkbox "Internet test (3 sites) after IP found". OFF (default): stop as soon as the IP is in range. ON: the IP must also pass the 3-site test (jio.com, selfcare.jio.com, api.jio.com).
