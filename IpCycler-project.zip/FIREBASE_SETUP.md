# IP Cycler Firebase setup

This build uses the existing Firebase Realtime Database project `kheloff-72149`.

## 1. Enable Anonymous Authentication
Firebase Console -> Authentication -> Sign-in method -> Anonymous -> Enable.

## 2. Create the initial global config
Realtime Database -> Data -> create:

config
  enabled: true

Keep `enabled` false if you want every client locked until the admin is ready.

## 3. Apply database rules
Use the contents of `database.rules.json` in Realtime Database -> Rules, then Publish.

The app can create only its own device record with status `pending` and can update its own metadata. A client cannot change its own status to `approved`, `disabled`, or `rejected`.

The administrator changes device status from the Firebase Console or a future admin panel.

## 4. Approve a device
After the APK is installed and opened once, a new device creates:

`devices/<anonymous-auth-uid>`

with:
- `status: pending`
- `uid`
- `createdAt`
- `lastSeen`
- `appVersion`

Change that device's `status` to `approved` in the Firebase Console.

## 5. Disable a device
Change its status to `disabled`.

## 6. Global kill switch
Change `config/enabled` to `false` to disable the IP Cycler for all devices. Set it back to `true` to enable it again.

The app fails closed: if authorization cannot be confirmed, START is disabled.
