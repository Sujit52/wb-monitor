package com.sujit.ipcycler

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

object AuthManager {
    enum class Status { CHECKING, PENDING, APPROVED, DISABLED, REJECTED, ERROR }

    @Volatile var status: Status = Status.CHECKING
        private set
    @Volatile var globalEnabled: Boolean = false
        private set
    @Volatile var deviceId: String? = null
        private set
    @Volatile var message: String = "Connecting to authorization server..."
        private set

    private var initialized = false
    private var deviceListener: ValueEventListener? = null
    private var configListener: ValueEventListener? = null
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseDatabase.getInstance() }

    @Synchronized
    fun initialize(context: Context, onChanged: () -> Unit) {
        if (initialized) return
        initialized = true

        auth.signInAnonymously().addOnCompleteListener { task ->
            if (!task.isSuccessful || auth.currentUser == null) {
                initialized = false // next app open will retry
                status = Status.ERROR
                globalEnabled = false
                message = "Firebase authentication failed. Check internet/Firebase setup."
                onChanged()
                return@addOnCompleteListener
            }
            deviceId = auth.currentUser!!.uid
            registerDevice()
            attachListeners(onChanged)
        }
    }

    private fun registerDevice() {
        val uid = auth.currentUser?.uid ?: return
        val ref = db.reference.child("devices").child(uid)
        ref.get().addOnSuccessListener { snap ->
            // Create the record only once. Nothing is ever re-written afterwards,
            // so the Firebase values stay fixed (no lastSeen / createdAt / appVersion).
            if (!snap.exists()) {
                val data = hashMapOf<String, Any>(
                    "uid" to uid,
                    "status" to "pending"
                )
                ref.setValue(data).addOnFailureListener {
                    status = Status.ERROR
                    globalEnabled = false
                    message = "Could not register this device."
                }
            }
        }.addOnFailureListener {
            status = Status.ERROR
            globalEnabled = false
            message = "Could not register/check this device."
        }
    }

    private fun attachListeners(onChanged: () -> Unit) {
        val uid = auth.currentUser?.uid ?: return
        val root = db.reference

        configListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                globalEnabled = snapshot.child("enabled").getValue(Boolean::class.java) == true
                if (status == Status.APPROVED) {
                    message = if (globalEnabled) "Authorized" else "App is disabled by administrator."
                }
                onChanged()
            }
            override fun onCancelled(error: DatabaseError) {
                globalEnabled = false
                status = Status.ERROR
                message = "Authorization server rejected the request."
                onChanged()
            }
        }
        root.child("config").addValueEventListener(configListener!!)

        deviceListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val s = snapshot.child("status").getValue(String::class.java)?.lowercase()
                status = when (s) {
                    "approved", "active" -> Status.APPROVED
                    "disabled" -> Status.DISABLED
                    "rejected", "removed" -> Status.REJECTED
                    else -> Status.PENDING
                }
                message = when (status) {
                    Status.APPROVED -> if (globalEnabled) "Authorized" else "App is disabled by administrator."
                    Status.DISABLED -> "This device has been disabled by administrator."
                    Status.REJECTED -> "This device is not authorized."
                    Status.PENDING -> "Waiting for administrator approval."
                    else -> message
                }
                onChanged()
            }
            override fun onCancelled(error: DatabaseError) {
                status = Status.ERROR
                globalEnabled = false
                message = "Could not read device authorization."
                onChanged()
            }
        }
        root.child("devices").child(uid).addValueEventListener(deviceListener!!)
    }

    fun canUse(): Boolean = status == Status.APPROVED && globalEnabled

    fun shortDeviceId(): String {
        val id = deviceId ?: return "-"
        return if (id.length <= 12) id else id.take(12)
    }
}
