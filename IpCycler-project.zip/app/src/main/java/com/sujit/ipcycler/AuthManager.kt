package com.sujit.ipcycler

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.provider.Settings
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

object AuthManager {
    enum class Status { CHECKING, PENDING, APPROVED, DISABLED, REJECTED, ERROR }

    /** After a successful server approval the app keeps working without internet for this many days. */
    const val OFFLINE_GRACE_DAYS = 7
    private const val DAY_MS = 24L * 60L * 60L * 1000L
    private const val GRACE_MS = OFFLINE_GRACE_DAYS * DAY_MS

    @Volatile var status: Status = Status.CHECKING
        private set
    @Volatile var globalEnabled: Boolean = false
        private set
    @Volatile var deviceId: String? = null
        private set
    @Volatile var message: String = "Connecting to authorization server..."
        private set

    private var initialized = false
    private var registering = false
    @Volatile private var deviceAnswered = false   // server has answered about this device
    @Volatile private var configAnswered = false   // server has answered about the global switch
    @Volatile private var connected = false        // Firebase connection is up right now
    private var lastSaveAt = 0L
    private var lastCommitAt = 0L
    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null

    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseDatabase.getInstance() }

    @Synchronized
    fun initialize(context: Context, onChanged: () -> Unit) {
        if (initialized) return
        initialized = true
        appContext = context.applicationContext
        prefs = context.applicationContext.getSharedPreferences("auth_cache", Context.MODE_PRIVATE)
        commitAge()

        // Already signed in on an earlier run: works with no internet at all.
        val existing = auth.currentUser
        if (existing != null) {
            deviceId = existing.uid
            attachListeners(onChanged)
            onChanged()
            return
        }

        auth.signInAnonymously().addOnCompleteListener { task ->
            if (!task.isSuccessful || auth.currentUser == null) {
                initialized = false // next app open will retry
                status = Status.ERROR
                globalEnabled = false
                message = "Firebase authentication failed. Check internet/Firebase setup."
                onChanged()
                return@addOnCompleteListener
            }
            deviceId = auth.currentUser!!.uid
            attachListeners(onChanged)
            onChanged()
        }
    }

    // The device record is created once, only when the server says it does not exist.
    // Nothing is ever re-written afterwards (no lastSeen / createdAt / appVersion).
    private fun registerOnce(uid: String) {
        if (registering) return
        registering = true
        db.reference.child("devices").child(uid)
            .setValue(hashMapOf<String, Any>("uid" to uid, "status" to "pending"))
            .addOnFailureListener {
                registering = false
                status = Status.ERROR
                message = "Could not register this device."
            }
    }

    private fun attachListeners(onChanged: () -> Unit) {
        val uid = auth.currentUser?.uid ?: return
        val root = db.reference

        db.getReference(".info/connected").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                connected = snapshot.getValue(Boolean::class.java) == true
                if (connected) heartbeat()
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        root.child("config").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                configAnswered = true
                globalEnabled = snapshot.child("enabled").getValue(Boolean::class.java) == true
                refreshState()
                onChanged()
            }
            override fun onCancelled(error: DatabaseError) {
                configAnswered = true
                globalEnabled = false
                status = Status.ERROR
                message = "Authorization server rejected the request."
                clearVerified()
                onChanged()
            }
        })

        root.child("devices").child(uid).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                deviceAnswered = true
                if (snapshot.exists()) registering = false else registerOnce(uid)
                val s = snapshot.child("status").getValue(String::class.java)?.lowercase()
                status = when (s) {
                    "approved", "active" -> Status.APPROVED
                    "disabled" -> Status.DISABLED
                    "rejected", "removed" -> Status.REJECTED
                    else -> Status.PENDING
                }
                refreshState()
                onChanged()
            }
            override fun onCancelled(error: DatabaseError) {
                deviceAnswered = true
                status = Status.ERROR
                globalEnabled = false
                message = "Could not read device authorization."
                clearVerified()
                onChanged()
            }
        })
    }

    private fun refreshState() {
        message = when (status) {
            Status.APPROVED -> if (globalEnabled) "Authorized" else "App is disabled by administrator."
            Status.DISABLED -> "This device has been disabled by administrator."
            Status.REJECTED -> "This device is not authorized."
            Status.PENDING -> "Waiting for administrator approval."
            else -> message
        }
        // Remember a fresh server approval (for offline use) or forget it when the server says no.
        if (status == Status.APPROVED && globalEnabled && deviceAnswered && configAnswered) {
            saveVerified()
        } else if (deviceAnswered && status != Status.APPROVED && status != Status.CHECKING) {
            clearVerified()
        } else if (configAnswered && !globalEnabled) {
            clearVerified()
        }
    }

    // ---------- offline grace (7 days after the last successful server approval) ----------
    // The age of the last approval is measured with the phone's monotonic clock
    // (SystemClock.elapsedRealtime), which does NOT change when the user edits date/time.
    // Only after a reboot (that clock restarts) the wall clock is consulted, and only forward:
    // setting the date back gains nothing.

    private fun bootCount(): Int {
        val cr = appContext?.contentResolver ?: return -1
        return try {
            Settings.Global.getInt(cr, Settings.Global.BOOT_COUNT, -1)
        } catch (e: Exception) {
            -1
        }
    }

    private fun computeAge(p: SharedPreferences, e: Long, w: Long, b: Int): Long {
        val age = p.getLong("age", 0L)
        val oe = p.getLong("obsElapsed", 0L)
        val ow = p.getLong("obsWall", 0L)
        val sameBoot = b == p.getInt("obsBoot", -2) && e >= oe
        return if (sameBoot) {
            age + (e - oe)
        } else {
            // Rebooted: unknown time may have passed. Count at least the uptime of this boot,
            // and the wall-clock gap if it moved forward.
            age + maxOf(maxOf(w - ow, 0L), e)
        }
    }

    /** Store how old the approval is now, so the aging survives app restarts and reboots. */
    private fun commitAge() {
        val p = prefs ?: return
        if (!p.getBoolean("approved", false)) return
        val e = SystemClock.elapsedRealtime()
        val w = System.currentTimeMillis()
        val b = bootCount()
        val age = computeAge(p, e, w, b)
        p.edit()
            .putLong("age", age)
            .putLong("obsElapsed", e)
            .putInt("obsBoot", b)
            .putLong("obsWall", w)
            .apply()
    }

    /** Fresh server approval: the offline window starts again from zero. */
    private fun saveVerified() {
        val p = prefs ?: return
        val uid = deviceId ?: return
        val e = SystemClock.elapsedRealtime()
        lastSaveAt = e
        p.edit()
            .putString("uid", uid)
            .putBoolean("approved", true)
            .putLong("age", 0L)
            .putLong("obsElapsed", e)
            .putInt("obsBoot", bootCount())
            .putLong("obsWall", System.currentTimeMillis())
            .apply()
    }

    private fun clearVerified() {
        prefs?.edit()?.remove("approved")?.remove("uid")?.apply()
    }

    private fun graceMsLeft(): Long {
        val p = prefs ?: return 0L
        val uid = deviceId ?: return 0L
        if (!p.getBoolean("approved", false) || p.getString("uid", null) != uid) return 0L
        val age = computeAge(p, SystemClock.elapsedRealtime(), System.currentTimeMillis(), bootCount())
        return (GRACE_MS - age).coerceAtLeast(0L)
    }

    private fun hadApprovalBefore(): Boolean {
        val p = prefs ?: return false
        return deviceId != null && p.getBoolean("approved", false) && p.getString("uid", null) == deviceId
    }

    /** True while the server cannot be reached but an earlier approval is still inside the window. */
    fun offlineGraceActive(): Boolean {
        if (deviceAnswered || configAnswered) return false // server reachable: it decides
        return graceMsLeft() > 0L
    }

    /** Call regularly while the app is open. */
    fun heartbeat() {
        val now = SystemClock.elapsedRealtime()
        if (connected && deviceAnswered && configAnswered && status == Status.APPROVED && globalEnabled &&
            now - lastSaveAt > 10L * 60L * 1000L
        ) {
            saveVerified()          // online and approved: window restarts
        } else if (now - lastCommitAt > 60L * 1000L) {
            lastCommitAt = now
            commitAge()             // offline: keep the aging saved
        }
    }

    // Deliberately vague: the screen never shows how long offline access lasts or how much is left.
    fun displayMessage(): String {
        if (offlineGraceActive()) return "Authorized"
        if (!deviceAnswered && !configAnswered && hadApprovalBefore()) {
            return "Internet connection required to verify this device."
        }
        return message
    }

    fun canUse(): Boolean = (status == Status.APPROVED && globalEnabled) || offlineGraceActive()

    fun shortDeviceId(): String {
        val id = deviceId ?: return "-"
        return if (id.length <= 12) id else id.take(12)
    }
}
