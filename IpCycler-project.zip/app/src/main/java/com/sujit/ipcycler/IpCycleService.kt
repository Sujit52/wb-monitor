package com.sujit.ipcycler

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.ConnectivityManager
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class IpCycleService : AccessibilityService() {

    companion object {
        @Volatile var instance: IpCycleService? = null

        // Lowercase text/description fragments used to find the Airplane mode switch.
        private val DEFAULT_LABELS = listOf(
            "airplane mode", "airplane", "flight mode", "aeroplane",
            "विमान", "हवाई जहाज", "फ्लाइट", "फ़्लाइट",
            "飞行", "飛行", "飛航", "비행기", "機内", "طيران",
            "modo avião", "modo avión", "modo avion", "mode avion", "flugmodus",
            "режим полёта", "режим полета", "pesawat", "uçak"
        )
    }

    override fun onServiceConnected() { instance = this }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startCycle(minB: Int, maxB: Int, maxTries: Int, custom: String, testNet: Boolean) {
        if (!AuthManager.canUse()) {
            State.add("Blocked: device is not authorized or app is disabled.")
            return
        }
        if (State.running) return
        State.running = true
        State.stop = false
        State.clear()
        Thread {
            try {
                runCycle(minB, maxB, maxTries, custom, testNet)
            } catch (e: Exception) {
                State.add("Error: ${e.message}")
            } finally {
                State.running = false
            }
            goToApp()
        }.start()
    }

    private fun runCycle(minB: Int, maxB: Int, maxTries: Int, custom: String, testNet: Boolean) {
        val cm = getSystemService(ConnectivityManager::class.java)
        val cur = IpUtils.cellularIp(cm)
        State.add("Current mobile IP: ${cur ?: "none"}")
        State.add(if (testNet) "Internet test: ON (3 sites)" else "Internet test: OFF (stops as soon as IP is in range)")
        if (cur != null && IpUtils.inRange(cur, minB, maxB)) {
            if (!testNet) {
                State.add("Already in target range. Stopped.")
                return
            }
            if (IpUtils.internetOk(cm)) {
                State.add("Already in target range with internet. Done.")
                return
            }
            State.add("In range but no internet, cycling...")
        }
        for (i in 1..maxTries) {
            if (State.stop) { State.add("Stopped."); return }
            if (!AuthManager.canUse()) { State.add("Stopped: authorization was revoked or app was disabled."); return }
            State.add("Try $i/$maxTries: toggling airplane mode...")
            if (!toggleAirplane(custom)) {
                State.add("Could not toggle airplane mode. Keep screen on, or type your phone's exact 'Airplane mode' label in the box and retry.")
                return
            }
            goToApp()
            val ip = waitForIp(cm, 30)
            if (ip == null) {
                if (State.stop) { State.add("Stopped."); return }
                State.add("No mobile IP after 30s (Wi-Fi off? Mobile data on?)")
                continue
            }
            State.add("New IP: $ip")
            if (IpUtils.inRange(ip, minB, maxB)) {
                if (!testNet) {
                    State.add("SUCCESS: $ip is in range. Stopped.")
                    return
                }
                if (IpUtils.internetOk(cm)) {
                    State.add("SUCCESS: $ip is in range and internet works. Stopped.")
                    return
                }
                State.add("In range but no internet, retrying...")
            }
        }
        State.add("Max tries reached.")
    }

    private fun toggleAirplane(custom: String): Boolean {
        val labels = buildLabels(custom)
        try {
            startActivity(
                Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // Some phones don't have this screen; quick settings fallback is used below.
        }
        pause(1500)
        if (!setAirplane(true, labels)) return false
        pause(3000)
        if (!setAirplane(false, labels)) return false
        pause(1000)
        return true
    }

    private fun airplaneOn(): Boolean =
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    private fun setAirplane(target: Boolean, labels: List<String>): Boolean {
        if (airplaneOn() == target) return true
        if (!tryClick(labels, 7000)) return false
        val end = SystemClock.uptimeMillis() + 6000
        while (SystemClock.uptimeMillis() < end) {
            if (airplaneOn() == target) return true
            pause(300)
        }
        return false
    }

    private fun buildLabels(custom: String): List<String> {
        val c = custom.trim().lowercase()
        return if (c.isEmpty()) DEFAULT_LABELS else listOf(c) + DEFAULT_LABELS
    }

    private fun roots(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { list.add(it) }
        try {
            for (w in windows) w.root?.let { list.add(it) }
        } catch (e: Exception) {
        }
        return list.filter { it.packageName?.toString() != packageName }
    }

    private fun collect(n: AccessibilityNodeInfo?, labels: List<String>, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        val t = "${n.text ?: ""} ${n.contentDescription ?: ""}".lowercase()
        if (t.isNotBlank() && labels.any { t.contains(it) }) out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), labels, out)
    }

    private fun tryClick(labels: List<String>, timeout: Long): Boolean {
        val start = SystemClock.uptimeMillis()
        var qsOpened = false
        while (SystemClock.uptimeMillis() - start < timeout) {
            for (root in roots()) {
                val found = ArrayList<AccessibilityNodeInfo>()
                collect(root, labels, found)
                for (n in found) {
                    var c: AccessibilityNodeInfo? = n
                    while (c != null && !c.isClickable) c = c.parent
                    if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
            }
            // If the settings page didn't have the switch, try the quick settings panel once.
            if (!qsOpened && SystemClock.uptimeMillis() - start > timeout / 2) {
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                qsOpened = true
            }
            pause(400)
        }
        return false
    }

    private fun waitForIp(cm: ConnectivityManager, secs: Int): String? {
        val end = SystemClock.uptimeMillis() + secs * 1000L
        while (SystemClock.uptimeMillis() < end) {
            if (State.stop) return null
            val ip = IpUtils.cellularIp(cm)
            if (ip != null) return ip
            pause(1000)
        }
        return null
    }

    private fun goToApp() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        } catch (e: Exception) {
        }
    }

    private fun pause(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { }
    }
}
