package com.sujit.ipcycler

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.ConnectivityManager
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class IpCycleService : AccessibilityService() {

    companion object {
        @Volatile var instance: IpCycleService? = null

        // Lowercase text/description fragments used to find the Airplane mode switch.
        private val DEFAULT_LABELS = listOf(
            "airplane mode", "airplane", "flight mode", "aeroplane",
            "विमान", "हवाई जहाज", "फ्लाइट", "फ़्लाइट",
            "飞行", "飛行", "飛航", "비행기", "機内", "طيران",
            "modo avião", "modo avión", "modo avion", "mode avion", "flugmodus",
            "режим полёта", "режим полета", "pesawat", "uçak"
        )
    }

    override fun onServiceConnected() { instance = this }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun testToggle(custom: String) {
        if (State.running) return
        State.add("Testing Airplane mode toggle...")
        Thread {
            val ok = try { toggleAirplane(custom) } catch (e: Exception) {
                State.add("TEST ERROR: ${e.javaClass.simpleName}: ${e.message ?: "unknown error"}")
                false
            }
            State.add(if (ok) "TEST OK: Airplane mode ON/OFF worked." else "TEST FAILED: Could not toggle Airplane mode.")
            Handler(Looper.getMainLooper()).post { goToApp() }
        }.start()
    }

    fun startCycle(minB: Int, maxB: Int, maxTries: Int, custom: String) {
        if (State.running) return
        State.running = true
        State.stop = false
        State.clear()
        Thread {
            try {
                runCycle(minB, maxB, maxTries, custom)
            } catch (e: Exception) {
                State.add("ERROR: ${e.javaClass.simpleName}: ${e.message ?: "unknown error"}")
            } finally {
                State.running = false
                Handler(Looper.getMainLooper()).post { goToApp() }
            }
        }.start()
    }

    private fun runCycle(minB: Int, maxB: Int, maxTries: Int, custom: String) {
        val cm = getSystemService(ConnectivityManager::class.java)
        if (minB !in 0..255 || maxB !in 0..255 || minB > maxB) {
            State.add("Invalid range: use 0-255 and MIN <= MAX.")
            return
        }
        if (maxTries !in 1..100) {
            State.add("Invalid max tries: use 1-100.")
            return
        }

        var lastIp = IpUtils.publicIp(cm)
        State.add("Current public mobile IP: ${lastIp ?: "not detected"}")
        if (lastIp != null && IpUtils.inRange(lastIp, minB, maxB) && IpUtils.internetOk(cm)) {
            State.add("Already in target range with internet. Done.")
            return
        }
        for (i in 1..maxTries) {
            if (State.stop) { State.add("Stopped."); return }
            State.add("Try $i/$maxTries: toggling airplane mode...")
            if (!toggleAirplane(custom)) {
                State.add("Could not toggle airplane mode. Keep screen on, or type your phone's exact 'Airplane mode' label in the box and retry.")
                return
            }
            Handler(Looper.getMainLooper()).post { goToApp() }
            val ip = waitForNewPublicIp(cm, lastIp, 30)
            if (ip == null) {
                State.add("No new public mobile IP after 30s. Check mobile data/signal.")
                continue
            }
            State.add("New public IP: $ip")
            lastIp = ip
            if (IpUtils.inRange(ip, minB, maxB)) {
                if (IpUtils.internetOk(cm)) {
                    State.add("SUCCESS: $ip is in range and internet works. Stopped.")
                    return
                } else {
                    State.add("In range but no internet, retrying...")
                }
            }
        }
        State.add("Max tries reached.")
    }

    private fun toggleAirplane(custom: String): Boolean {
        val labels = buildLabels(custom)
        try {
            startActivity(
                Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // Some phones don't have this screen; quick settings fallback is used below.
        }
        pause(1500)
        if (!setAirplane(true, labels)) return false
        pause(3000)
        if (!setAirplane(false, labels)) return false
        pause(1000)
        return true
    }

    private fun airplaneOn(): Boolean = try {
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (_: Exception) {
        false
    }

    private fun setAirplane(target: Boolean, labels: List<String>): Boolean {
        if (airplaneOn() == target) return true
        if (!tryClick(labels, 7000)) return false
        val end = SystemClock.uptimeMillis() + 6000
        while (SystemClock.uptimeMillis() < end) {
            if (airplaneOn() == target) return true
            pause(300)
        }
        return false
    }

    private fun buildLabels(custom: String): List<String> {
        val c = custom.trim().lowercase()
        return if (c.isEmpty()) DEFAULT_LABELS else listOf(c) + DEFAULT_LABELS
    }

    private fun roots(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { list.add(it) }
        try {
            for (w in windows) w.root?.let { list.add(it) }
        } catch (e: Exception) {
        }
        return list.filter { it.packageName?.toString() != packageName }
    }

    private fun collect(n: AccessibilityNodeInfo?, labels: List<String>, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        val t = "${n.text ?: ""} ${n.contentDescription ?: ""}".lowercase()
        if (t.isNotBlank() && labels.any { t.contains(it) }) out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), labels, out)
    }

    private fun tryClick(labels: List<String>, timeout: Long): Boolean {
        val start = SystemClock.uptimeMillis()
        var qsOpened = false
        while (SystemClock.uptimeMillis() - start < timeout) {
            for (root in roots()) {
                val found = ArrayList<AccessibilityNodeInfo>()
                collect(root, labels, found)
                for (n in found) {
                    var c: AccessibilityNodeInfo? = n
                    while (c != null && !c.isClickable) c = c.parent
                    if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
            }
            // If the settings page didn't have the switch, try the quick settings panel once.
            if (!qsOpened && SystemClock.uptimeMillis() - start > timeout / 2) {
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                qsOpened = true
            }
            pause(400)
        }
        return false
    }

    private fun waitForNewPublicIp(cm: ConnectivityManager, oldIp: String?, secs: Int): String? {
        val end = SystemClock.uptimeMillis() + secs * 1000L
        while (SystemClock.uptimeMillis() < end) {
            if (State.stop) return null
            val ip = IpUtils.publicIp(cm)
            if (ip != null && ip != oldIp) return ip
            pause(1200)
        }
        return null
    }

    private fun goToApp() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        } catch (e: Exception) {
        }
    }

    private fun pause(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { }
    }
}
