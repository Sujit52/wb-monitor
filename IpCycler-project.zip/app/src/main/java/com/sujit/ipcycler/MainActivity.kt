package com.sujit.ipcycler

import android.app.Activity
import android.content.ClipboardManager
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        // 2nd octet range (100.MIN-MAX.x.x). Fixed in code, not editable from the UI.
        const val MIN_OCTET = 64
        const val MAX_OCTET = 95
    }

    private lateinit var status: TextView
    private lateinit var authStatus: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var etTries: EditText
    private lateinit var etLabel: EditText
    private lateinit var cbNetTest: CheckBox
    private lateinit var btnStart: Button
    private var lastLog = ""

    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 700)
        }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun numField(hint: String, def: String) = EditText(this).apply {
        this.hint = hint
        setText(def)
        inputType = InputType.TYPE_CLASS_NUMBER
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        val title = TextView(this).apply {
            text = "IP Cycler (no root)"
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(4)) }
        authStatus = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, dp(8)) }

        val btnEnable = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { openAccessibilitySettings() }
        }
        val btnCopyId = Button(this).apply {
            text = "Copy Device ID"
            setOnClickListener {
                val id = AuthManager.deviceId
                if (id == null) Toast.makeText(this@MainActivity, "Device ID not ready", Toast.LENGTH_SHORT).show()
                else {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("IP Cycler Device ID", id))
                    Toast.makeText(this@MainActivity, "Device ID copied", Toast.LENGTH_SHORT).show()
                }
            }
        }

        etTries = numField("Max tries", "100")
        etLabel = EditText(this).apply { hint = "Airplane mode label (optional)" }

        cbNetTest = CheckBox(this).apply {
            text = "Internet test (3 sites) after IP found"
            isChecked = getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("net_test", false)
            setOnCheckedChangeListener { _, on ->
                getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putBoolean("net_test", on).apply()
            }
        }

        val range = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(etTries, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        btnStart = Button(this).apply {
            text = "START"
            setOnClickListener { start() }
        }
        val btnStop = Button(this).apply {
            text = "STOP"
            setOnClickListener { State.stop = true }
        }
        val btnClear = Button(this).apply {
            text = "CLEAR LOG"
            setOnClickListener {
                State.clear()
                lastLog = "\u0000" // differs from "" so refresh() really redraws the empty log
                refresh()
            }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            addView(btnStart, lp()); addView(btnStop, lp()); addView(btnClear, lp())
        }

        logView = TextView(this).apply {
            textSize = 13f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        scroll = ScrollView(this).apply { addView(logView) }

        root.addView(title)
        root.addView(status)
        root.addView(authStatus)
        root.addView(btnEnable)
        root.addView(btnCopyId)
        root.addView(range)
        root.addView(cbNetTest)
        root.addView(etLabel)
        root.addView(buttons)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        AuthManager.initialize(this) { runOnUiThread { refresh() } }
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val serviceOn = IpCycleService.instance != null
        status.text = if (serviceOn) "Accessibility service: ON" else "Accessibility service: OFF"

        val state = AuthManager.status
        val global = if (AuthManager.globalEnabled) "ON" else "OFF"
        AuthManager.heartbeat()
        val head = if (AuthManager.offlineGraceActive()) "Status: Authorized" else "Server: ${state.name} | Global: $global"
        authStatus.text = "$head | Device: ${AuthManager.shortDeviceId()}\n${AuthManager.displayMessage()}"
        btnStart.isEnabled = AuthManager.canUse() && serviceOn && !State.running

        val t = State.text()
        if (t != lastLog) {
            lastLog = t
            logView.text = t
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun start() {
        if (!AuthManager.canUse()) {
            Toast.makeText(this, "Device is not authorized by administrator", Toast.LENGTH_LONG).show()
            return
        }
        val svc = IpCycleService.instance
        if (svc == null) {
            Toast.makeText(this, "Pehle Accessibility service ON karo", Toast.LENGTH_LONG).show()
            return
        }
        val tr = etTries.text.toString().toIntOrNull() ?: 100
        if (tr !in 1..100) {
            Toast.makeText(this, "Tries 1-100 ke beech rakho", Toast.LENGTH_LONG).show()
            return
        }
        svc.startCycle(MIN_OCTET, MAX_OCTET, tr, etLabel.text.toString(), cbNetTest.isChecked)
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "IP Cycler service ko ON karo", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Accessibility settings open nahi hui", Toast.LENGTH_LONG).show()
        }
    }
}
