package com.sujit.ipcycler

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var etMin: EditText
    private lateinit var etMax: EditText
    private lateinit var etTries: EditText
    private lateinit var etLabel: EditText
    private var lastLog = ""

    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 500)
        }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun numField(hint: String, def: String) = EditText(this).apply {
        this.hint = hint
        setText(def)
        inputType = InputType.TYPE_CLASS_NUMBER
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        val title = TextView(this).apply {
            text = "IP Cycler (no root)"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(8), 0, dp(8))
        }
        val btnEnable = Button(this).apply {
            text = "Enable service"
            setOnClickListener { enableService() }
        }

        etMin = numField("2nd octet min", "64")
        etMax = numField("2nd octet max", "95")
        etTries = numField("Max tries", "30")
        etLabel = EditText(this).apply { hint = "Airplane mode label (optional)" }

        val range = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            addView(etMin, lp())
            addView(etMax, lp())
            addView(etTries, lp())
        }

        val btnStart = Button(this).apply {
            text = "START"
            setOnClickListener { start() }
        }
        val btnStop = Button(this).apply {
            text = "STOP"
            setOnClickListener { State.stop = true }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            addView(btnStart, lp())
            addView(btnStop, lp())
        }

        logView = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        scroll = ScrollView(this).apply { addView(logView) }

        root.addView(title)
        root.addView(status)
        root.addView(btnEnable)
        root.addView(range)
        root.addView(etLabel)
        root.addView(buttons)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val on = IpCycleService.instance != null
        status.text = if (on) "Service: ON" else "Service: OFF - tap 'Enable service'"
        val t = State.text()
        if (t != lastLog) {
            lastLog = t
            logView.text = t
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun start() {
        val svc = IpCycleService.instance
        if (svc == null) {
            Toast.makeText(this, "Pehle service enable karo", Toast.LENGTH_LONG).show()
            return
        }
        val mn = etMin.text.toString().toIntOrNull() ?: 64
        val mx = etMax.text.toString().toIntOrNull() ?: 95
        val tr = etTries.text.toString().toIntOrNull() ?: 30
        svc.startCycle(mn, mx, tr, etLabel.text.toString())
    }

    // Works only if WRITE_SECURE_SETTINGS was granted once via ADB. Otherwise opens Accessibility settings.
    private fun enableService() {
        try {
            val cn = ComponentName(this, IpCycleService::class.java).flattenToString()
            val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (!cur.contains(cn)) {
                val v = if (cur.isEmpty()) cn else "$cur:$cn"
                Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, v)
            }
            Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            Toast.makeText(this, "Service enabled", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "IP Cycler ko ON karo", Toast.LENGTH_LONG).show()
        }
    }
}
