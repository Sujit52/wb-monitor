package com.sujit.ipcycler

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.URL

object State {
    private val sb = StringBuilder()
    @Volatile var running = false
    @Volatile var stop = false

    @Synchronized fun add(s: String) {
        sb.append(s).append('\n')
        if (sb.length > 8000) sb.delete(0, sb.length - 6000)
    }

    @Synchronized fun text(): String = sb.toString()
    @Synchronized fun clear() { sb.setLength(0) }
}

object IpUtils {
    @Suppress("DEPRECATION")
    fun cellularNetwork(cm: ConnectivityManager): Network? {
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return n
        }
        return null
    }

    fun publicIp(cm: ConnectivityManager): String? {
        val n = cellularNetwork(cm) ?: return null
        return try {
            val conn = (n.openConnection(URL("https://api.ipify.org")) as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = false
                requestMethod = "GET"
            }
            conn.inputStream.bufferedReader().use { it.readText().trim() }.also { conn.disconnect() }
                .takeIf { it.matches(Regex("\\d{1,3}(\\.\\d{1,3}){3}")) }
        } catch (_: Exception) {
            null
        }
    }

    // First octet fixed at 100, second octet between lo..hi (Jio CGNAT: 100.64 - 100.95)
    fun inRange(ip: String, lo: Int, hi: Int): Boolean {
        val p = ip.split(".")
        if (p.size != 4) return false
        val a = p[0].toIntOrNull() ?: return false
        val b = p[1].toIntOrNull() ?: return false
        return a == 100 && b in lo..hi
    }

    fun internetOk(cm: ConnectivityManager): Boolean {
        val n = cellularNetwork(cm) ?: return false
        return try {
            val c = n.openConnection(URL("https://www.gstatic.com/generate_204")) as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            c.instanceFollowRedirects = false
            val code = c.responseCode
            c.disconnect()
            code == 204 || code == 200
        } catch (e: Exception) {
            false
        }
    }
}
