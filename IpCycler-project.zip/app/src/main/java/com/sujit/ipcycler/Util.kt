package com.sujit.ipcycler

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger

object State {
    private val sb = StringBuilder()
    @Volatile var running = false
    @Volatile var stop = false

    @Synchronized fun add(s: String) {
        sb.append(s).append('\n')
        if (sb.length > 8000) sb.delete(0, sb.length - 6000)
    }

    @Synchronized fun text(): String = sb.toString()
    @Synchronized fun clear() { sb.setLength(0) }
}

object IpUtils {
    // Sites checked in parallel over the mobile-data network.
    private val SITES = listOf(
        "https://www.jio.com",
        "https://selfcare.jio.com",
        "https://api.jio.com"
    )
    // How many sites must respond for the internet test to pass.
    private const val MIN_OK = 1
    // Per-site timeout in milliseconds.
    private const val SITE_TIMEOUT = 2500

    @Suppress("DEPRECATION")
    fun cellularNetwork(cm: ConnectivityManager): Network? {
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return n
        }
        return null
    }

    fun cellularIp(cm: ConnectivityManager): String? {
        val n = cellularNetwork(cm) ?: return null
        val lp = cm.getLinkProperties(n) ?: return null
        for (a in lp.linkAddresses) {
            val addr = a.address
            if (addr is Inet4Address && !addr.isLoopbackAddress) return addr.hostAddress
        }
        return null
    }

    // First octet fixed at 100, second octet between lo..hi (Jio CGNAT: 100.64 - 100.95)
    fun inRange(ip: String, lo: Int, hi: Int): Boolean {
        val p = ip.split(".")
        if (p.size != 4) return false
        val a = p[0].toIntOrNull() ?: return false
        val b = p[1].toIntOrNull() ?: return false
        return a == 100 && b in lo..hi
    }

    fun internetOk(cm: ConnectivityManager): Boolean {
        val n = cellularNetwork(cm) ?: return false
        val okCount = AtomicInteger(0)
        val redirects = setOf(301, 302, 303, 307, 308)

        val threads = SITES.map { u ->
            Thread {
                try {
                    val c = n.openConnection(URL(u)) as HttpURLConnection
                    c.connectTimeout = SITE_TIMEOUT
                    c.readTimeout = SITE_TIMEOUT
                    c.instanceFollowRedirects = false
                    c.requestMethod = "GET"
                    val code = c.responseCode
                    val ok = if (code in redirects) {
                        // Redirect inside Jio is normal; redirect elsewhere = captive portal / blocked.
                        val loc = c.getHeaderField("Location") ?: ""
                        loc.startsWith("/") || loc.contains("jio", ignoreCase = true)
                    } else {
                        code > 0
                    }
                    c.disconnect()
                    if (ok) {
                        okCount.incrementAndGet()
                        State.add("  [OK] $u ($code)")
                    } else {
                        State.add("  [x] $u ($code)")
                    }
                } catch (e: Exception) {
                    State.add("  [x] $u failed")
                }
            }.also { it.start() }
        }
        for (t in threads) {
            try { t.join(4000) } catch (e: InterruptedException) { }
        }
        return okCount.get() >= MIN_OK
    }
}
