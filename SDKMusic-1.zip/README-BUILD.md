This archive is intended to be extracted at the GitHub repository root.
Expected repository layout:
  .github/workflows/build-apk.yml
  SDKMusic/settings.gradle
  SDKMusic/build.gradle
  SDKMusic/app/...
Use the included workflow; it builds from SDKMusic/.


v5.2 compile fix: MainActivity.onPause() is public because WebAppInterface.Listener declares it as public.
