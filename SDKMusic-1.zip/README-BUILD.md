This archive is intended to be extracted at the GitHub repository root.
Expected repository layout:
  .github/workflows/build-apk.yml
  SDKMusic/settings.gradle
  SDKMusic/build.gradle
  SDKMusic/app/...
Use the included workflow; it builds from SDKMusic/.
