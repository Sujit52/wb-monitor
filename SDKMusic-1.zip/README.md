# SDK Music v2

Fixed/updated:
- Native ExoPlayer playback for real background + screen-off playback.
- MediaSession metadata with title and duration/position for lock-screen/media controls.
- Play/pause/seek/stop controls are handled by Android.
- Full-screen loading overlay appears only on the first successful launch.
- Double-back exit behavior.
- Modern NetworkCapabilities connectivity check.
- Removed broad cleartext/mixed-content configuration.
- WebView permissions are no longer blindly granted.
- GitHub Actions now provisions Gradle 8.7 explicitly.

Important:
The website must expose a normal `http://` or `https://` media URL through `currentSrc` for native playback. If it uses blob/MSE-only playback, the native handoff cannot directly access the media bytes and the WebView player remains the fallback.
