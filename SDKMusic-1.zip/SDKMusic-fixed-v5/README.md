# SDK Music v5

This version fixes the background-playback lifecycle.

Key changes:
- Foreground media service starts for every website audio play event, including blob:/MSE URLs.
- WebView remains the player when ExoPlayer cannot consume the stream.
- ExoPlayer is used only when a real http/https media URL can be handed off.
- Activity never explicitly calls WebView.onPause() when minimized.
- Media service remains in the same application process so the foreground-service priority protects the WebView process.
- Notification metadata/progress is updated from WebView playback as a fallback.
- Native Media3 playback gets User-Agent and Referer.
- Media playback foreground-service type is declared.
- Service uses START_STICKY and does not stop when the task is removed.

Build:
- Keep the existing repository structure with the Android project inside SDKMusic/.
- Use the existing GitHub Actions workflow that builds from SDKMusic/.
