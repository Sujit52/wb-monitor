package com.sdk.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import java.util.Collections;

public class MusicService extends Service {
    public static final String CHANNEL_ID = "sdk_music_playback";
    public static final int NOTIF_ID = 101;

    public static final String ACTION_PLAY_URL = "com.sdk.music.PLAY_URL";
    public static final String ACTION_PAUSE = "com.sdk.music.PAUSE";
    public static final String ACTION_RESUME = "com.sdk.music.RESUME";
    public static final String ACTION_STOP = "com.sdk.music.ACTION_STOP";
    public static final String ACTION_NATIVE_READY = "com.sdk.music.NATIVE_READY";
    public static final String ACTION_NATIVE_ERROR = "com.sdk.music.NATIVE_ERROR";
    public static final String ACTION_WEB_PAUSE = "com.sdk.music.WEB_PAUSE";
    public static final String ACTION_WEB_RESUME = "com.sdk.music.WEB_RESUME";
    public static final String ACTION_WEB_PROGRESS = "com.sdk.music.WEB_PROGRESS";

    private ExoPlayer player;
    private MediaSessionCompat mediaSession;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String currentTitle = "SDK Music";
    private String currentUrl = "";
    private String pageUrl = "";
    private String userAgent = "";
    private long webDuration = 0L;
    private long webPosition = 0L;
    private boolean nativeReady = false;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateSessionAndNotification();
            handler.postDelayed(this, 1000);
        }
    };

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onPlaybackStateChanged(int state) {
            if (state == Player.STATE_READY && player != null && player.getPlayWhenReady()) {
                nativeReady = true;
                sendBroadcast(new Intent(ACTION_NATIVE_READY).setPackage(getPackageName()));
            }
            if (state == Player.STATE_ENDED) {
                nativeReady = false;
                sendBroadcast(new Intent(ACTION_NATIVE_ERROR)
                        .putExtra("reason", "ended").setPackage(getPackageName()));
            }
            updateSessionAndNotification();
        }

        @Override public void onIsPlayingChanged(boolean isPlaying) {
            updateSessionAndNotification();
        }

        @Override public void onPlayerError(PlaybackException error) {
            nativeReady = false;
            sendBroadcast(new Intent(ACTION_NATIVE_ERROR)
                    .putExtra("reason", error.getErrorCodeName())
                    .setPackage(getPackageName()));
            if (player != null) {
                player.stop();
                player.clearMediaItems();
            }
            // Keep this service alive because WebView may be the active player.
            updateSessionAndNotification();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannelIfNeeded();

        player = new ExoPlayer.Builder(this).build();
        player.setAudioAttributes(
                new androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(), true);
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        player.addListener(listener);

        mediaSession = new MediaSessionCompat(this, "SDKMusicSession");
        mediaSession.setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS |
                MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() {
                if (nativeReady && player != null) player.play();
                else sendBroadcast(new Intent(ACTION_WEB_RESUME).setPackage(getPackageName()));
                updateSessionAndNotification();
            }
            @Override public void onPause() {
                if (nativeReady && player != null) player.pause();
                else sendBroadcast(new Intent(ACTION_WEB_PAUSE).setPackage(getPackageName()));
                updateSessionAndNotification();
            }
            @Override public void onStop() {
                stopPlayback();
            }
            @Override public void onSeekTo(long pos) {
                if (nativeReady && player != null) player.seekTo(pos);
                else webPosition = Math.max(0, pos);
                updateSessionAndNotification();
            }
        });
        mediaSession.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // Critical: enter foreground before any playback/network work.
        startForegroundCompat();

        if (intent == null) return START_STICKY;
        String action = intent.getAction();

        if (ACTION_PLAY_URL.equals(action)) {
            currentUrl = intent.getStringExtra("url");
            currentTitle = safe(intent.getStringExtra("title"), "SDK Music");
            pageUrl = intent.getStringExtra("pageUrl");
            userAgent = intent.getStringExtra("userAgent");
            webDuration = Math.max(0, intent.getLongExtra("durationMs", 0));
            webPosition = Math.max(0, intent.getLongExtra("positionMs", 0));
            nativeReady = false;

            if (currentUrl != null && (currentUrl.startsWith("https://") || currentUrl.startsWith("http://"))) {
                playNative(currentUrl);
            } else {
                // blob:/MSE or empty URL: WebView remains the actual player.
                updateSessionAndNotification();
            }
        } else if (ACTION_PAUSE.equals(action)) {
            if (nativeReady && player != null) player.pause();
            else sendBroadcast(new Intent(ACTION_WEB_PAUSE).setPackage(getPackageName()));
            updateSessionAndNotification();
        } else if (ACTION_RESUME.equals(action)) {
            if (nativeReady && player != null) player.play();
            else sendBroadcast(new Intent(ACTION_WEB_RESUME).setPackage(getPackageName()));
            updateSessionAndNotification();
                } else if (ACTION_WEB_PROGRESS.equals(action)) {
            currentTitle = safe(intent.getStringExtra("title"), currentTitle);
            webDuration = Math.max(0, intent.getLongExtra("durationMs", webDuration));
            webPosition = Math.max(0, intent.getLongExtra("positionMs", webPosition));
            updateSessionAndNotification();
        } else if (ACTION_STOP.equals(action)) {
            stopPlayback();
        }
        return START_STICKY;
    }

    private void playNative(String url) {
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true);
        if (userAgent != null && !userAgent.isEmpty()) http.setUserAgent(userAgent);
        if (pageUrl != null && !pageUrl.isEmpty()) {
            http.setDefaultRequestProperties(
                    Collections.singletonMap("Referer", pageUrl));
        }

        try {
            player.stop();
            player.clearMediaItems();
            MediaItem item = MediaItem.fromUri(url);
            DefaultMediaSourceFactory factory = new DefaultMediaSourceFactory(http);
            player.setMediaSource(factory.createMediaSource(item));
            player.prepare();
            player.play();
        } catch (Throwable t) {
            nativeReady = false;
            sendBroadcast(new Intent(ACTION_NATIVE_ERROR)
                    .putExtra("reason", t.getClass().getSimpleName())
                    .setPackage(getPackageName()));
        }
        updateSessionAndNotification();
    }

    private void updateSessionAndNotification() {
        if (mediaSession == null) return;

        boolean playing = nativeReady && player != null && player.isPlaying();
        long pos = nativeReady && player != null ? Math.max(0, player.getCurrentPosition()) : webPosition;
        long dur = nativeReady && player != null && player.getDuration() != C.TIME_UNSET
                ? Math.max(0, player.getDuration()) : webDuration;

        int state = playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;

        PlaybackStateCompat ps = new PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY |
                        PlaybackStateCompat.ACTION_PAUSE |
                        PlaybackStateCompat.ACTION_PLAY_PAUSE |
                        PlaybackStateCompat.ACTION_SEEK_TO |
                        PlaybackStateCompat.ACTION_STOP)
                .setState(state, pos, 1.0f)
                .build();
        mediaSession.setPlaybackState(ps);
        mediaSession.setMetadata(new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, currentTitle)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "SDK Music")
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, dur)
                .build());

        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification(playing));
    }

    private Notification buildNotification(boolean playing) {
        PendingIntent content = PendingIntent.getActivity(
                this, 0,
                new Intent(this, MainActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent pp = new Intent(this, MusicService.class)
                .setAction(playing ? ACTION_PAUSE : ACTION_RESUME);
        PendingIntent ppPending = PendingIntent.getService(
                this, 1, pp, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, MusicService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(currentTitle)
                .setContentText("SDK Music")
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .addAction(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        playing ? "Pause" : "Play", ppPending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending)
                .setStyle(new MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void startForegroundCompat() {
        Notification n = buildNotification(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void stopPlayback() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.stop();
            player.clearMediaItems();
        }
        nativeReady = false;
        sendBroadcast(new Intent(ACTION_WEB_PAUSE).setPackage(getPackageName()));
        if (mediaSession != null) mediaSession.setActive(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel c = new NotificationChannel(
                        CHANNEL_ID, "Music playback", NotificationManager.IMPORTANCE_LOW);
                c.setDescription("SDK Music background playback controls");
                c.setShowBadge(false);
                nm.createNotificationChannel(c);
            }
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Never stop a playing media service because the Activity task was removed.
        startForegroundCompat();
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.removeListener(listener);
            player.release();
            player = null;
        }
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    private static String safe(String s, String fallback) {
        return s == null || s.isEmpty() ? fallback : s;
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    public static void play(Context ctx, String url, String title, String pageUrl,
                             String userAgent, double duration, double position) {
        Intent i = new Intent(ctx, MusicService.class)
                .setAction(ACTION_PLAY_URL)
                .putExtra("url", url)
                .putExtra("title", title)
                .putExtra("pageUrl", pageUrl)
                .putExtra("userAgent", userAgent)
                .putExtra("durationMs", duration > 0 ? (long)(duration * 1000) : 0)
                .putExtra("positionMs", position > 0 ? (long)(position * 1000) : 0);
        androidx.core.content.ContextCompat.startForegroundService(ctx, i);
    }

    public static void updateWebProgress(Context ctx, String title, double duration, double position) {
        Intent i = new Intent(ctx, MusicService.class)
                .setAction(ACTION_WEB_PROGRESS)
                .putExtra("title", title)
                .putExtra("durationMs", duration > 0 ? (long)(duration * 1000) : 0)
                .putExtra("positionMs", position > 0 ? (long)(position * 1000) : 0);
        ctx.startService(i);
    }

    public static void pause(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_PAUSE));
    }
    public static void resume(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_RESUME));
    }
    public static void stop(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_STOP));
    }
}
