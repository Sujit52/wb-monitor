# SDK Music v4

This version keeps the WebView as the website UI/fallback and uses a persistent Android foreground media service for native playback when the site exposes a normal HTTP(S) media URL.

Key changes:
- Foreground service starts before playback work.
- ExoPlayer uses media audio attributes and network wake mode.
- Native player receives the website User-Agent and Referer.
- Native playback errors no longer destroy the service immediately; WebView fallback remains available.
- MediaSession metadata and playback position are updated continuously.
- WebView audio is paused only after ExoPlayer reaches READY.
- Service is not tied to the Activity task (`stopWithTask=false`).
