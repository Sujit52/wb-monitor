# SDK Music — Android WebView App

Yeh ek ready Android Studio project hai jo https://sdkmusic.free.nf ko ek WebView
ke andar ek native music player app ki tarah open karta hai. App icon aapke diye
gaye gold music-note icon se generate kiya gaya hai (sabhi densities + adaptive icon).

## Kya-kya set hai
- WebView autoplay / audio allowed (`mediaPlaybackRequiresUserGesture = false`)
- Mixed content allowed (site http/https dono resources load kar sake)
- Pull-to-refresh
- App khulte waqt beech screen mein logo pulse-animation + gold spinner (loading nice dikhta hai, sirf pehli baar)
- **Background playback**: app minimize karne ya screen off karne par bhi music chalta rehta hai
- **Notification media controls**: gaana bajte hi status bar/lock screen mein Play/Pause/Stop dikhta hai, wahi se control ho sakta hai
- "Internet nahi hai" screen + Retry button
- Andar ke links WebView ke andar hi khulte hain (browser mein nahi jaate)
- Downloads (agar site kisi song ko download karwaye) seedha Downloads folder mein jaate hain
- Back button WebView history mein peeche jaata hai, warna app close

### Background playback kaise kaam karta hai
Jab bhi site ka koi `<audio>`/`<video>` element play/pause hota hai, ek chhota
JS hook Android ko batata hai. Us par app ek foreground service + notification
chalu kar deta hai jo process ko background mein zinda rakhta hai — isliye
app minimize/screen-off hone par bhi gaana rukta nahi. Pehli baar app kholte
waqt Android **notification permission** maangega — usse **Allow** karna zaroori
hai, warna notification controls nahi dikhenge (music background mein tab bhi
bajega, bas notification nahi dikhegi).

## Build kaise karein (APK banane ke liye)
1. **Android Studio** install karein (free): https://developer.android.com/studio
2. Is poore `SDKMusic` folder ko unzip karke Android Studio mein **Open** karein
   (File → Open → SDKMusic folder select karein).
3. Pehli baar Gradle sync hoga (internet chahiye) — bas thoda wait karein.
4. Top menu se: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK yahan milegi: `app/build/outputs/apk/debug/app-debug.apk`
6. Ye APK apne phone mein bhej ke install kar lein (Unknown sources allow karna padega).

> Note: Maine yahan (is chat environment) mein directly APK compile nahi ki hai
> kyunki yahan Android SDK/Gradle install nahi hai aur internet bhi band hai —
> isliye poora ready source project de raha hoon jo Android Studio mein 1-click
> build ho jaayega.

## Agar Android Studio install nahi karna
GitHub par is folder ko push karke **GitHub Actions** se free mein APK build
karwaya ja sakta hai — bolo to uska bhi ek ready workflow file bana deta hoon.

## App ka package name
`com.sdk.music` — agar Play Store pe daalna ho to isse apna unique
package name (jaise `com.yourname.sdkmusic`) mein badal lena, `app/build.gradle`
aur folder structure dono jagah.
