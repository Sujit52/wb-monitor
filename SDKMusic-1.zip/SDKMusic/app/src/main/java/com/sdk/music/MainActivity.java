package com.sdk.music;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.Collections;

public class MainActivity extends AppCompatActivity implements WebAppInterface.Listener {
    private static final String TAG = "SDKMusic";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout offlineLayout;
    private LinearLayout loadingOverlay;
    private ImageView loadingLogo;
    private android.animation.ObjectAnimator pulseAnimator;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean pageLoaded = false;
    private long lastBackPress = 0;
    private String lastKnownTitle = "SDK Music";
    private boolean nativePlaybackActive = false;

    private final BroadcastReceiver playbackReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (MusicService.ACTION_WEB_PAUSE.equals(action)) {
                webView.evaluateJavascript("(()=>{const a=[...document.querySelectorAll('audio,video')].find(x=>!x.paused&&!x.ended);if(a)a.pause();})()", null);
            } else if (MusicService.ACTION_WEB_RESUME.equals(action)) {
                webView.evaluateJavascript("(()=>{const a=[...document.querySelectorAll('audio,video')].find(x=>x.paused&&!x.ended);if(a)a.play().catch(()=>{});})()", null);
            } else if (MusicService.ACTION_NATIVE_READY.equals(action)) {
                nativePlaybackActive = true;
                // Native player is confirmed READY; now stop the WebView copy.
                webView.evaluateJavascript(PAUSE_WEB_MEDIA_JS, null);
            } else if (MusicService.ACTION_NATIVE_ERROR.equals(action)) {
                nativePlaybackActive = false;
                // Native playback failed. Keep WebView playback alive as fallback.
                Toast.makeText(MainActivity.this,
                        "Native playback unavailable — website player continue hoga",
                        Toast.LENGTH_SHORT).show();
            }
        }
    };

    private static final String TARGET_URL = "https://sdkmusic.free.nf";
    private static final int NOTIF_PERMISSION_CODE = 55;
    private static final String PREFS = "sdk_music_prefs";
    private static final String PREF_FIRST_LOAD_DONE = "first_load_done";

    /*
     * We still use the website as the UI/player selector, but the actual audio
     * is handed to Android's ExoPlayer in MusicService. This is the important
     * part that makes screen-off/background playback reliable.
     */
    private static final String HOOK_JS =
            "(function(){" +
            "if(window.__sdkHooked) return; window.__sdkHooked=true;" +
            "function active(){var a=[...document.querySelectorAll('audio,video')];" +
            "for(var i=0;i<a.length;i++){if(!a[i].paused && !a[i].ended) return a[i];}" +
            "return null;}" +
            "function firePlay(el){" +
            " if(!window.SDKMusic||!el)return;" +
            " var u=el.currentSrc||el.src||'';" +
            " var t=document.title||'SDK Music';" +
            " window.SDKMusic.onAudioPlay(t,u,Number.isFinite(el.duration)?el.duration:-1,el.currentTime||0);" +
            "}" +
            "function hook(el){if(el.__sdkHook)return;el.__sdkHook=true;" +
            "el.addEventListener('play',function(){firePlay(el);});" +
            "el.addEventListener('pause',function(){if(window.SDKMusic)window.SDKMusic.onAudioPause();});" +
            "el.addEventListener('ended',function(){if(window.SDKMusic)window.SDKMusic.onAudioEnded();});" +
            "el.addEventListener('timeupdate',function(){if(!el.paused&&window.SDKMusic)" +
            "window.SDKMusic.onAudioProgress(Number.isFinite(el.duration)?el.duration:-1,el.currentTime||0);});" +
            "el.addEventListener('durationchange',function(){if(!el.paused)firePlay(el);});" +
            "}" +
            "document.querySelectorAll('audio,video').forEach(hook);" +
            "new MutationObserver(function(){document.querySelectorAll('audio,video').forEach(hook);})" +
            ".observe(document.documentElement,{childList:true,subtree:true});" +
            "})();";

    /*
     * Runs before the site's own JavaScript. This is important for background
     * playback because many web players listen to Page Visibility and pause
     * their <audio>/<video> when the WebView becomes hidden. It also hooks
     * media elements created inside frames when the frame has the same origin.
     */
    private static final String DOCUMENT_START_JS =
            "(function(){" +
            "try{" +
            "Object.defineProperty(Document.prototype,'hidden',{configurable:true,get:function(){return false;}});" +
            "Object.defineProperty(Document.prototype,'visibilityState',{configurable:true,get:function(){return 'visible';}});" +
            "document.addEventListener('visibilitychange',function(e){e.stopImmediatePropagation();},true);" +
            "window.addEventListener('pagehide',function(e){e.stopImmediatePropagation();},true);" +
            "window.addEventListener('blur',function(e){e.stopImmediatePropagation();},true);" +
            "}catch(e){}" +
            "function hook(el){" +
            " if(!el||el.__sdkHook)return; el.__sdkHook=true;" +
            " function fire(){try{if(window.SDKMusic){" +
            " var u=el.currentSrc||el.src||'';" +
            " var t=document.title||'SDK Music';" +
            " window.SDKMusic.onAudioPlay(t,u,Number.isFinite(el.duration)?el.duration:-1,el.currentTime||0);" +
            " }}catch(e){}}" +
            " el.addEventListener('play',fire,true);" +
            " el.addEventListener('durationchange',function(){if(!el.paused)fire();},true);" +
            " el.addEventListener('pause',function(){try{if(window.SDKMusic)window.SDKMusic.onAudioPause();}catch(e){}},true);" +
            " el.addEventListener('ended',function(){try{if(window.SDKMusic)window.SDKMusic.onAudioEnded();}catch(e){}},true);" +
            " el.addEventListener('timeupdate',function(){try{if(!el.paused&&window.SDKMusic)window.SDKMusic.onAudioProgress(Number.isFinite(el.duration)?el.duration:-1,el.currentTime||0);}catch(e){}},true);" +
            " }" +
            " function scan(){try{document.querySelectorAll('audio,video').forEach(hook);}catch(e){}}" +
            " scan();" +
            " new MutationObserver(scan).observe(document.documentElement||document,{childList:true,subtree:true});" +
            "})();";

    private static final String PAUSE_WEB_MEDIA_JS =
            "(function(){var a=[...document.querySelectorAll('audio,video')];" +
            "a.forEach(function(x){if(!x.paused){x.pause();x.volume=0;}});})();";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        offlineLayout = findViewById(R.id.offlineLayout);
        loadingOverlay = findViewById(R.id.loadingOverlay);
        loadingLogo = findViewById(R.id.loadingLogo);
        Button retryButton = findViewById(R.id.retryButton);

        setupWebView();
        startLoaderAnimation();

        retryButton.setOnClickListener(v -> loadSite());
        swipeRefresh.setOnRefreshListener(this::loadSite);

        requestNotificationPermissionIfNeeded();

        IntentFilter filter = new IntentFilter();
        filter.addAction(MusicService.ACTION_NATIVE_READY);
        filter.addAction(MusicService.ACTION_NATIVE_ERROR);
        filter.addAction(MusicService.ACTION_WEB_PAUSE);
        filter.addAction(MusicService.ACTION_WEB_RESUME);
        androidx.core.content.ContextCompat.registerReceiver(
                this, playbackReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);

        // Only show the full-screen loading animation on the first-ever launch.
        boolean firstLaunch = !getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(PREF_FIRST_LOAD_DONE, false);
        if (!firstLaunch) {
            loadingOverlay.setVisibility(View.GONE);
        }

        loadSite();
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setUserAgentString(settings.getUserAgentString() + " SDKMusicApp/2.0");

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new WebAppInterface(this), "SDKMusic");

        // Inject before page scripts when the installed WebView supports it.
        // This catches media elements inside same-origin frames and prevents
        // page-visibility based players from stopping when the Activity is hidden.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                WebViewCompat.addDocumentStartJavaScript(
                        webView,
                        DOCUMENT_START_JS,
                        new java.util.HashSet<>(Collections.singletonList("https://sdkmusic.free.nf/*")));
            } catch (Throwable ignored) {
                // Fall back to the onPageFinished hook below.
            }
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoaded = true;
                swipeRefresh.setRefreshing(false);
                view.evaluateJavascript(HOOK_JS, null);
                hideLoadingOverlay();
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean(PREF_FIRST_LOAD_DONE, true).apply();
            }

            @Override public void onReceivedError(WebView view, int errorCode,
                                                  String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (!isConnected()) showOffline();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                // Do not blindly grant every WebView permission.
                runOnUiThread(() -> {
                    String[] allowed = request.getResources();
                    java.util.ArrayList<String> safe = new java.util.ArrayList<>();
                    for (String r : allowed) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                            safe.add(r);
                        }
                    }
                    if (!safe.isEmpty()) request.grant(safe.toArray(new String[0]));
                    else request.deny();
                });
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                android.app.DownloadManager.Request request =
                        new android.app.DownloadManager.Request(android.net.Uri.parse(url));
                request.setMimeType(mimeType);
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) request.addRequestHeader("cookie", cookie);
                if (userAgent != null) request.addRequestHeader("User-Agent", userAgent);
                String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setDescription("Downloading file...");
                request.setTitle(fileName);
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(
                        android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(
                        android.os.Environment.DIRECTORY_DOWNLOADS, fileName);
                android.app.DownloadManager dm =
                        (android.app.DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(request);
                    Toast.makeText(this, "Download shuru ho gaya", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Download start nahi hua", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override public void onPlay(String title, String url, double duration, double position) {
        Log.d(TAG, "WEB PLAY title=" + title + " url=" + url + " duration=" + duration);
        lastKnownTitle = title == null || title.isEmpty() ? "SDK Music" : title;

        // Do NOT pause WebView yet. The native player first has to prove that it
        // can actually open the URL. If it cannot (blob/MSE/DRM/etc.), the website
        // player remains the fallback.
        nativePlaybackActive = false;
        // Always start the foreground media service when the website starts audio.
        // Even blob:/MSE streams cannot be handed to ExoPlayer directly, but the
        // foreground service keeps the app's playback process protected while the
        // WebView remains the actual player.
        MusicService.play(getApplicationContext(), url, lastKnownTitle,
                webView.getUrl(), webView.getSettings().getUserAgentString(),
                duration, position);
    }

    @Override public void onPause() {
        // IMPORTANT: do not call webView.onPause(). Android WebView's explicit
        // onPause() suspends media playback. The foreground MusicService is the
        // lifecycle guard while the Activity is in the background.
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override public void onEnded() {
        MusicService.stop(getApplicationContext());
    }

    @Override public void onProgress(double duration, double position) {
        // Keep notification metadata/progress correct even when the WebView is
        // the actual player (blob:/MSE streams that ExoPlayer cannot open).
        MusicService.updateWebProgress(getApplicationContext(),
                lastKnownTitle, duration, position);
    }

    private void startLoaderAnimation() {
        pulseAnimator = android.animation.ObjectAnimator.ofFloat(
                loadingLogo, "scaleX", 1f, 1.12f, 1f);
        pulseAnimator.setDuration(1100);
        pulseAnimator.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        pulseAnimator.setInterpolator(new android.view.animation.LinearInterpolator());
        pulseAnimator.start();

        android.animation.ObjectAnimator pulseY = android.animation.ObjectAnimator.ofFloat(
                loadingLogo, "scaleY", 1f, 1.12f, 1f);
        pulseY.setDuration(1100);
        pulseY.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        pulseY.setInterpolator(new android.view.animation.LinearInterpolator());
        pulseY.start();
    }

    private void hideLoadingOverlay() {
        if (loadingOverlay.getVisibility() != View.VISIBLE) return;
        loadingOverlay.animate().alpha(0f).setDuration(220)
                .withEndAction(() -> {
                    loadingOverlay.setVisibility(View.GONE);
                    loadingOverlay.setAlpha(1f);
                }).start();
    }

    private void loadSite() {
        if (isConnected()) {
            offlineLayout.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            if (webView.getUrl() == null || !pageLoaded) {
                webView.loadUrl(TARGET_URL);
            } else {
                webView.reload();
            }
        } else {
            showOffline();
        }
        swipeRefresh.setRefreshing(false);
    }

    private void showOffline() {
        offlineLayout.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);
        hideLoadingOverlay();
    }

    private boolean isConnected() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    NOTIF_PERMISSION_CODE);
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // Web history first; press back again within 2 seconds to exit.
            if (webView.canGoBack()) {
                webView.goBack();
                return true;
            }
            if (System.currentTimeMillis() - lastBackPress < 2000) {
                finishAndRemoveTask();
                return true;
            }
            lastBackPress = System.currentTimeMillis();
            Toast.makeText(this, "Exit ke liye dobara Back dabaye", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(playbackReceiver); } catch (Exception ignored) {}
        if (pulseAnimator != null) pulseAnimator.cancel();
        webView.destroy();
        super.onDestroy();
    }
}
