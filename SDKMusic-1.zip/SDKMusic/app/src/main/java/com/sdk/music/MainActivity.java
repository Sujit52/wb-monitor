package com.sdk.music;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity implements WebAppInterface.Listener {

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout offlineLayout;
    private LinearLayout loadingOverlay;
    private ImageView loadingLogo;
    private ObjectAnimator pulseAnimator;

    private boolean isFirstLoad = true;
    private String lastKnownTitle = "SDK Music";

    private static final String TARGET_URL = "https://sdkmusic.free.nf";
    private static final int NOTIF_PERMISSION_CODE = 55;

    // Makes the page think it's always visible (many sites auto-pause audio on tab-hidden)
    // and hooks every <audio>/<video> element so play/pause/ended events reach Android.
    private static final String HOOK_JS =
            "(function(){" +
            "if(window.__sdkHooked) return; window.__sdkHooked = true;" +
            "try{" +
            "Object.defineProperty(document,'hidden',{get:function(){return false;}});" +
            "Object.defineProperty(document,'visibilityState',{get:function(){return 'visible';}});" +
            "document.addEventListener('visibilitychange', function(e){e.stopImmediatePropagation();}, true);" +
            "}catch(e){}" +
            "function fire(type){" +
            "  if(type==='play'){ var t=(document.title||'SDK Music'); if(window.SDKMusic) window.SDKMusic.onAudioPlay(t); }" +
            "  else if(type==='pause'){ if(window.SDKMusic) window.SDKMusic.onAudioPause(); }" +
            "  else if(type==='ended'){ if(window.SDKMusic) window.SDKMusic.onAudioEnded(); }" +
            "}" +
            "function hook(el){" +
            "  if(el.__h) return; el.__h = true;" +
            "  el.addEventListener('play', function(){ fire('play'); });" +
            "  el.addEventListener('pause', function(){ fire('pause'); });" +
            "  el.addEventListener('ended', function(){ fire('ended'); });" +
            "}" +
            "document.querySelectorAll('audio,video').forEach(hook);" +
            "new MutationObserver(function(){ document.querySelectorAll('audio,video').forEach(hook); })" +
            "  .observe(document.documentElement, {childList:true, subtree:true});" +
            "})();";

    private static final String TOGGLE_JS =
            "(function(){" +
            "var els=document.querySelectorAll('audio,video');" +
            "for(var i=0;i<els.length;i++){ if(!els[i].paused){ els[i].pause(); return; } }" +
            "for(var j=0;j<els.length;j++){ els[j].play(); return; }" +
            "})();";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        offlineLayout = findViewById(R.id.offlineLayout);
        loadingOverlay = findViewById(R.id.loadingOverlay);
        loadingLogo = findViewById(R.id.loadingLogo);
        Button retryButton = findViewById(R.id.retryButton);

        setupWebView();
        startLoaderAnimation();

        retryButton.setOnClickListener(v -> loadSite());
        swipeRefresh.setOnRefreshListener(this::loadSite);

        requestNotificationPermissionIfNeeded();

        // Wires the notification's Play/Pause button (and lock-screen/headset controls)
        // back to whichever <audio>/<video> element is currently active on the page.
        MusicService.setController(() ->
                runOnUiThread(() -> webView.evaluateJavascript(TOGGLE_JS, null)));

        loadSite();
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setUserAgentString(settings.getUserAgentString() + " SDKMusicApp/1.0");

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new WebAppInterface(this), "SDKMusic");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                swipeRefresh.setRefreshing(false);
                view.evaluateJavascript(HOOK_JS, null);
                if (isFirstLoad) {
                    isFirstLoad = false;
                    hideLoadingOverlay();
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (!isConnected()) {
                    showOffline();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mimeType);
            request.addRequestHeader("cookie", CookieManager.getInstance().getCookie(url));
            request.addRequestHeader("User-Agent", userAgent);
            request.setDescription("Downloading file...");
            request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, contentDisposition, mimeType));
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                Toast.makeText(getApplicationContext(), "Download shuru ho gaya", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // --- WebAppInterface.Listener: fired from JS when page audio state changes ---

    @Override
    public void onPlay(String title) {
        lastKnownTitle = title;
        MusicService.notifyPlaying(getApplicationContext(), title);
    }

    @Override
    public void onPause() {
        MusicService.notifyPaused(getApplicationContext(), lastKnownTitle);
    }

    @Override
    public void onEnded() {
        MusicService.stop(getApplicationContext());
    }

    // --- Loading overlay ---

    private void startLoaderAnimation() {
        pulseAnimator = ObjectAnimator.ofFloat(loadingLogo, "scaleX", 1f, 1.12f, 1f);
        pulseAnimator.setDuration(1100);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setInterpolator(new LinearInterpolator());
        ObjectAnimator pulseY = ObjectAnimator.ofFloat(loadingLogo, "scaleY", 1f, 1.12f, 1f);
        pulseY.setDuration(1100);
        pulseY.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.start();
        pulseY.start();
    }

    private void hideLoadingOverlay() {
        loadingOverlay.animate()
                .alpha(0f)
                .setDuration(300)
                .withEndAction(() -> loadingOverlay.setVisibility(View.GONE))
                .start();
    }

    // --- Site load / connectivity ---

    private void loadSite() {
        if (isConnected()) {
            offlineLayout.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(TARGET_URL);
        } else {
            showOffline();
        }
        swipeRefresh.setRefreshing(false);
    }

    private void showOffline() {
        offlineLayout.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);
        if (isFirstLoad) {
            isFirstLoad = false;
            hideLoadingOverlay();
        }
    }

    private boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERMISSION_CODE);
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // Deliberately NOT calling webView.onPause()/onResume() around app background/foreground —
    // that would suspend JS timers and stop audio. The WebView keeps running as long as the
    // process is alive, which the foreground MusicService notification guarantees while playing.

    @Override
    protected void onDestroy() {
        MusicService.setController(null);
        webView.destroy();
        super.onDestroy();
    }
}
