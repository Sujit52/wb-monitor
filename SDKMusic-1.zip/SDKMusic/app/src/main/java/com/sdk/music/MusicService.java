package com.sdk.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;

public class MusicService extends Service {
    public static final String CHANNEL_ID = "sdk_music_playback";
    public static final int NOTIF_ID = 101;

    public static final String ACTION_PLAY_URL = "com.sdk.music.PLAY_URL";
    public static final String ACTION_PAUSE = "com.sdk.music.PAUSE";
    public static final String ACTION_RESUME = "com.sdk.music.RESUME";
    public static final String ACTION_STOP = "com.sdk.music.ACTION_STOP";

    private ExoPlayer player;
    private MediaSessionCompat mediaSession;
    private String currentTitle = "SDK Music";
    private String currentUrl = "";
    private boolean userStopped = false;
    private final Handler progressHandler = new Handler(Looper.getMainLooper());
    private final Runnable progressRunnable = new Runnable() {
        @Override public void run() {
            if (player != null && player.isPlaying()) {
                updateSessionAndNotification();
                progressHandler.postDelayed(this, 1000);
            }
        }
    };

    private final Player.Listener playerListener = new Player.Listener() {
        @Override public void onIsPlayingChanged(boolean isPlaying) {
            updateSessionAndNotification();
        }
        @Override public void onPlaybackStateChanged(int state) {
            if (state == Player.STATE_ENDED) {
                updateSessionAndNotification();
            }
            updateSessionAndNotification();
        }
        @Override public void onMediaItemTransition(@Nullable MediaItem mediaItem, int reason) {
            updateSessionAndNotification();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannelIfNeeded();

        player = new ExoPlayer.Builder(this).build();
        player.addListener(playerListener);

        mediaSession = new MediaSessionCompat(this, "SDKMusicSession");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { if (player != null) player.play(); }
            @Override public void onPause() { if (player != null) player.pause(); }
            @Override public void onStop() { stopPlayback(); }
            @Override public void onSeekTo(long pos) { if (player != null) player.seekTo(pos); }
        });
        mediaSession.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String action = intent.getAction();
        if (ACTION_PLAY_URL.equals(action)) {
            String url = intent.getStringExtra("url");
            String title = intent.getStringExtra("title");
            if (url != null && !url.isEmpty()) {
                currentTitle = title == null || title.isEmpty() ? "SDK Music" : title;
                currentUrl = url;
                userStopped = false;
                playUrl(url);
            }
        } else if (ACTION_PAUSE.equals(action)) {
            if (player != null) player.pause();
        } else if (ACTION_RESUME.equals(action)) {
            if (player != null) player.play();
        } else if (ACTION_STOP.equals(action)) {
            stopPlayback();
            return START_NOT_STICKY;
        }

        return START_STICKY;
    }

    private void playUrl(String url) {
        MediaItem item = MediaItem.fromUri(url);
        player.setMediaItem(item);
        player.prepare();
        player.play();
        progressHandler.removeCallbacks(progressRunnable);
        progressHandler.post(progressRunnable);
        startForeground(NOTIF_ID, buildNotification());
        updateSessionAndNotification();
    }

    private void updateSessionAndNotification() {
        if (mediaSession == null || player == null) return;

        int state;
        if (player.getPlaybackState() == Player.STATE_ENDED) {
            state = PlaybackStateCompat.STATE_NONE;
        } else if (player.isPlaying()) {
            state = PlaybackStateCompat.STATE_PLAYING;
        } else {
            state = PlaybackStateCompat.STATE_PAUSED;
        }

        long position = player.getCurrentPosition();
        long duration = player.getDuration();
        if (duration == C.TIME_UNSET || duration < 0) duration = -1;

        long actions = PlaybackStateCompat.ACTION_PLAY |
                PlaybackStateCompat.ACTION_PAUSE |
                PlaybackStateCompat.ACTION_PLAY_PAUSE |
                PlaybackStateCompat.ACTION_SEEK_TO |
                PlaybackStateCompat.ACTION_STOP;

        PlaybackStateCompat stateObj = new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, position, player.getPlaybackParameters().speed)
                .setExtras(null)
                .build();

        mediaSession.setPlaybackState(stateObj);
        if (player.isPlaying()) {
            progressHandler.removeCallbacks(progressRunnable);
            progressHandler.postDelayed(progressRunnable, 1000);
        }
        mediaSession.setMetadata(new android.support.v4.media.MediaMetadataCompat.Builder()
                .putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_TITLE, currentTitle)
                .putString(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_ARTIST, "SDK Music")
                .putLong(android.support.v4.media.MediaMetadataCompat.METADATA_KEY_DURATION, duration)
                .build());

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification());
    }

    private Notification buildNotification() {
        Intent openApp = new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent playPause = new Intent(this, MusicService.class)
                .setAction(player != null && player.isPlaying() ? ACTION_PAUSE : ACTION_RESUME);
        PendingIntent playPausePending = PendingIntent.getService(this, 1, playPause,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, MusicService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        int icon = player != null && player.isPlaying()
                ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        String label = player != null && player.isPlaying() ? "Pause" : "Play";

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(currentTitle)
                .setContentText("SDK Music")
                .setContentIntent(contentIntent)
                .setOngoing(player != null && player.isPlaying())
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .addAction(icon, label, playPausePending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending)
                .setStyle(new MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .build();
    }

    private void stopPlayback() {
        progressHandler.removeCallbacks(progressRunnable);
        if (player != null) {
            player.stop();
            player.clearMediaItems();
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "Music playback", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("SDK Music background playback controls");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    @Override public void onDestroy() {
        progressHandler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.removeListener(playerListener);
            player.release();
            player = null;
        }
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    public static void play(Context ctx, String url, String title) {
        Intent i = new Intent(ctx, MusicService.class)
                .setAction(ACTION_PLAY_URL)
                .putExtra("url", url)
                .putExtra("title", title);
        androidx.core.content.ContextCompat.startForegroundService(ctx, i);
    }

    public static void pause(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_PAUSE));
    }

    public static void resume(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_RESUME));
    }

    public static void stop(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_STOP));
    }
}
