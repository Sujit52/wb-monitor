package com.sdk.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

import java.util.Collections;

public class MusicService extends Service {
    public static final String CHANNEL_ID = "sdk_music_playback";
    public static final int NOTIF_ID = 101;

    public static final String ACTION_PLAY_URL = "com.sdk.music.PLAY_URL";
    public static final String ACTION_PAUSE = "com.sdk.music.PAUSE";
    public static final String ACTION_RESUME = "com.sdk.music.RESUME";
    public static final String ACTION_STOP = "com.sdk.music.ACTION_STOP";
    public static final String ACTION_NATIVE_READY = "com.sdk.music.NATIVE_READY";
    public static final String ACTION_NATIVE_ERROR = "com.sdk.music.NATIVE_ERROR";

    private ExoPlayer player;
    private MediaSessionCompat mediaSession;
    private String currentTitle = "SDK Music";
    private String currentUrl = "";
    private String pageUrl = "";
    private String userAgent = "";
    private boolean stopping = false;

    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateSessionAndNotification();
            if (player != null && (player.isPlaying() || player.getPlaybackState() == Player.STATE_BUFFERING)) {
                handler.postDelayed(this, 1000);
            }
        }
    };

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onPlaybackStateChanged(int state) {
            updateSessionAndNotification();
            if (state == Player.STATE_READY && player != null && player.getPlayWhenReady()) {
                sendBroadcast(new Intent(ACTION_NATIVE_READY).setPackage(getPackageName()));
            }
            if (state == Player.STATE_ENDED) {
                sendBroadcast(new Intent(ACTION_NATIVE_ERROR)
                        .putExtra("reason", "ended").setPackage(getPackageName()));
            }
        }

        @Override public void onIsPlayingChanged(boolean isPlaying) {
            updateSessionAndNotification();
        }

        @Override public void onPlayerError(PlaybackException error) {
            sendBroadcast(new Intent(ACTION_NATIVE_ERROR)
                    .putExtra("reason", error.getErrorCodeName())
                    .setPackage(getPackageName()));
            // Do not kill the service here. The WebView fallback may still be playing.
            handler.removeCallbacks(ticker);
            if (player != null) player.stop();
            updateSessionAndNotification();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannelIfNeeded();

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();

        player = new ExoPlayer.Builder(this).build();
        player.setAudioAttributes(
                androidx.media3.common.AudioAttributes.DEFAULT, true);
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        player.addListener(listener);

        mediaSession = new MediaSessionCompat(this, "SDKMusicSession");
        mediaSession.setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS |
                MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() {
                if (player != null) player.play();
                updateSessionAndNotification();
            }
            @Override public void onPause() {
                if (player != null) player.pause();
                updateSessionAndNotification();
            }
            @Override public void onStop() { stopPlayback(); }
            @Override public void onSeekTo(long pos) {
                if (player != null) player.seekTo(pos);
                updateSessionAndNotification();
            }
        });
        mediaSession.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // Start foreground BEFORE doing any network/player work.
        startForegroundCompat();

        if (intent == null) return START_STICKY;
        String action = intent.getAction();

        if (ACTION_PLAY_URL.equals(action)) {
            String url = intent.getStringExtra("url");
            String title = intent.getStringExtra("title");
            pageUrl = intent.getStringExtra("pageUrl");
            userAgent = intent.getStringExtra("userAgent");
            if (url != null && !url.isEmpty()) {
                currentTitle = (title == null || title.isEmpty()) ? "SDK Music" : title;
                currentUrl = url;
                stopping = false;
                playUrl(url);
            }
        } else if (ACTION_PAUSE.equals(action)) {
            if (player != null) player.pause();
            updateSessionAndNotification();
        } else if (ACTION_RESUME.equals(action)) {
            if (player != null) player.play();
            updateSessionAndNotification();
        } else if (ACTION_STOP.equals(action)) {
            stopPlayback();
        }
        return START_STICKY;
    }

    private void playUrl(String url) {
        handler.removeCallbacks(ticker);
        stopping = false;

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true);

        if (userAgent != null && !userAgent.isEmpty()) http.setUserAgent(userAgent);
        if (pageUrl != null && !pageUrl.isEmpty()) {
            http.setDefaultRequestProperties(
                    Collections.singletonMap("Referer", pageUrl));
        }

        if (player == null) return;

        player.stop();
        player.clearMediaItems();

        MediaItem item = MediaItem.fromUri(url);
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(http);
        player.setMediaSource(mediaSourceFactory.createMediaSource(item));
        player.prepare();
        player.play();
        updateSessionAndNotification();
        handler.post(ticker);
    }

    private void updateSessionAndNotification() {
        if (player == null || mediaSession == null) return;

        int state;
        if (player.getPlaybackState() == Player.STATE_ENDED) state = PlaybackStateCompat.STATE_NONE;
        else if (player.isPlaying()) state = PlaybackStateCompat.STATE_PLAYING;
        else if (player.getPlaybackState() == Player.STATE_BUFFERING) state = PlaybackStateCompat.STATE_BUFFERING;
        else state = PlaybackStateCompat.STATE_PAUSED;

        long duration = player.getDuration();
        if (duration == C.TIME_UNSET || duration < 0) duration = 0;

        PlaybackStateCompat ps = new PlaybackStateCompat.Builder()
                .setActions(
                        PlaybackStateCompat.ACTION_PLAY |
                        PlaybackStateCompat.ACTION_PAUSE |
                        PlaybackStateCompat.ACTION_PLAY_PAUSE |
                        PlaybackStateCompat.ACTION_SEEK_TO |
                        PlaybackStateCompat.ACTION_STOP)
                .setState(state, Math.max(0, player.getCurrentPosition()),
                        player.getPlaybackParameters().speed)
                .build();
        mediaSession.setPlaybackState(ps);

        mediaSession.setMetadata(new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, currentTitle)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "SDK Music")
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, duration)
                .build());

        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification());

        handler.removeCallbacks(ticker);
        if (player.isPlaying() || player.getPlaybackState() == Player.STATE_BUFFERING) {
            handler.postDelayed(ticker, 1000);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        boolean playing = player != null && player.isPlaying();

        Intent pp = new Intent(this, MusicService.class)
                .setAction(playing ? ACTION_PAUSE : ACTION_RESUME);
        PendingIntent ppPending = PendingIntent.getService(this, 1, pp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, MusicService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(currentTitle)
                .setContentText("SDK Music")
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .addAction(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        playing ? "Pause" : "Play", ppPending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending)
                .setStyle(new MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void startForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, buildNotification());
        }
    }

    private void stopPlayback() {
        stopping = true;
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.stop();
            player.clearMediaItems();
        }
        if (mediaSession != null) mediaSession.setActive(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel c = new NotificationChannel(
                        CHANNEL_ID, "Music playback", NotificationManager.IMPORTANCE_LOW);
                c.setDescription("SDK Music background playback controls");
                c.setShowBadge(false);
                nm.createNotificationChannel(c);
            }
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Keep the media service alive. Do not stop it when the WebView task is removed.
        if (player != null && (player.isPlaying() || player.getPlayWhenReady())) {
            startForegroundCompat();
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.removeListener(listener);
            player.release();
            player = null;
        }
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    public static void play(Context ctx, String url, String title, String pageUrl, String userAgent) {
        Intent i = new Intent(ctx, MusicService.class)
                .setAction(ACTION_PLAY_URL)
                .putExtra("url", url)
                .putExtra("title", title)
                .putExtra("pageUrl", pageUrl)
                .putExtra("userAgent", userAgent);
        androidx.core.content.ContextCompat.startForegroundService(ctx, i);
    }
    public static void pause(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_PAUSE));
    }
    public static void resume(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_RESUME));
    }
    public static void stop(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_STOP));
    }
}
