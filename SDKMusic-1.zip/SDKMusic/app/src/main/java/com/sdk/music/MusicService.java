package com.sdk.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;

public class MusicService extends Service {

    public static final String CHANNEL_ID = "sdk_music_playback";
    public static final int NOTIF_ID = 101;

    public static final String ACTION_TOGGLE = "com.sdk.music.ACTION_TOGGLE";
    public static final String ACTION_STOP = "com.sdk.music.ACTION_STOP";

    /** Bridge back into the WebView living in MainActivity. Set/cleared by the Activity. */
    public interface PlaybackController {
        void togglePlayPause();
    }

    private static PlaybackController controller;

    public static void setController(PlaybackController c) {
        controller = c;
    }

    private MediaSessionCompat mediaSession;
    private PowerManager.WakeLock wakeLock;
    private boolean isPlaying = false;
    private String currentTitle = "SDK Music";

    @Override
    public void onCreate() {
        super.onCreate();
        createChannelIfNeeded();

        mediaSession = new MediaSessionCompat(this, "SDKMusicSession");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override
            public void onPlay() {
                if (controller != null) controller.togglePlayPause();
            }

            @Override
            public void onPause() {
                if (controller != null) controller.togglePlayPause();
            }
        });
        mediaSession.setActive(true);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SDKMusic::PlaybackWakeLock");
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_TOGGLE.equals(action)) {
                if (controller != null) controller.togglePlayPause();
                return START_STICKY;
            } else if (ACTION_STOP.equals(action)) {
                stopPlayback();
                return START_NOT_STICKY;
            }

            String title = intent.getStringExtra("title");
            boolean playing = intent.getBooleanExtra("playing", true);
            currentTitle = title != null ? title : currentTitle;
            isPlaying = playing;
            startForeground(NOTIF_ID, buildNotification());
            updatePlaybackState();

            if (wakeLock != null && isPlaying && !wakeLock.isHeld()) {
                wakeLock.acquire(4 * 60 * 60 * 1000L); // safety timeout: 4 hours
            } else if (wakeLock != null && !isPlaying && wakeLock.isHeld()) {
                wakeLock.release();
            }
        }
        return START_STICKY;
    }

    private void stopPlayback() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(true);
        stopSelf();
    }

    private void updatePlaybackState() {
        int state = isPlaying ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
        PlaybackStateCompat playbackState = new PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE)
                .setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1f)
                .build();
        mediaSession.setPlaybackState(playbackState);
    }

    private Notification buildNotification() {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent toggleIntent = new Intent(this, MusicService.class).setAction(ACTION_TOGGLE);
        PendingIntent togglePendingIntent = PendingIntent.getService(
                this, 1, toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, MusicService.class).setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
                this, 2, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        int playPauseIcon = isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        String playPauseLabel = isPlaying ? "Pause" : "Play";

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(currentTitle)
                .setContentText(isPlaying ? "SDK Music - playing" : "SDK Music - paused")
                .setContentIntent(contentIntent)
                .setOngoing(isPlaying)
                .setOnlyAlertOnce(true)
                .addAction(playPauseIcon, playPauseLabel, togglePendingIntent)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
                .setStyle(new MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .build();
    }

    private void createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "Music playback", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Playback controls for SDK Music");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (mediaSession != null) mediaSession.release();
        super.onDestroy();
    }

    // Convenience static helpers used by MainActivity -----------------------------------

    /**
     * Starts the foreground service right away, as soon as the app/page has loaded —
     * NOT gated on detecting an actual "play" event from the page's JS. This is what
     * keeps the app process alive (and therefore the WebView + its audio) when the
     * user minimizes the app or turns the screen off, even if the site's player never
     * fires a detectable play/pause event.
     */
    public static void ensureRunning(Context ctx) {
        Intent i = new Intent(ctx, MusicService.class);
        i.putExtra("title", "SDK Music");
        i.putExtra("playing", false);
        androidx.core.content.ContextCompat.startForegroundService(ctx, i);
    }

    public static void notifyPlaying(Context ctx, String title) {
        Intent i = new Intent(ctx, MusicService.class);
        i.putExtra("title", title);
        i.putExtra("playing", true);
        androidx.core.content.ContextCompat.startForegroundService(ctx, i);
    }

    public static void notifyPaused(Context ctx, String title) {
        Intent i = new Intent(ctx, MusicService.class);
        i.putExtra("title", title);
        i.putExtra("playing", false);
        androidx.core.content.ContextCompat.startForegroundService(ctx, i);
    }

    public static void stop(Context ctx) {
        Intent i = new Intent(ctx, MusicService.class);
        i.setAction(ACTION_STOP);
        ctx.startService(i);
    }
}
