package com.sdk.music;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

/**
 * Exposed to the web page as `window.SDKMusic`.
 * The page's injected JS hooks call these when any <audio>/<video>
 * element on the site starts, pauses, or finishes playing.
 */
public class WebAppInterface {

    public interface Listener {
        void onPlay(String title);
        void onPause();
        void onEnded();
    }

    private final Listener listener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public WebAppInterface(Listener listener) {
        this.listener = listener;
    }

    @JavascriptInterface
    public void onAudioPlay(final String title) {
        mainHandler.post(() -> listener.onPlay(title));
    }

    @JavascriptInterface
    public void onAudioPause() {
        mainHandler.post(listener::onPause);
    }

    @JavascriptInterface
    public void onAudioEnded() {
        mainHandler.post(listener::onEnded);
    }
}
