package com.sdk.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

public class MusicService extends Service {
    public static final String CHANNEL_ID = "sdk_music_playback";
    public static final int NOTIF_ID = 101;

    public static final String ACTION_PLAY_URL = "com.sdk.music.PLAY_URL";
    public static final String ACTION_PAUSE = "com.sdk.music.PAUSE";
    public static final String ACTION_RESUME = "com.sdk.music.RESUME";
    public static final String ACTION_STOP = "com.sdk.music.ACTION_STOP";
    public static final String ACTION_NATIVE_READY = "com.sdk.music.NATIVE_READY";
    public static final String ACTION_NATIVE_ERROR = "com.sdk.music.NATIVE_ERROR";

    private ExoPlayer player;
    private MediaSessionCompat mediaSession;
    private String currentTitle = "SDK Music";
    private String currentUrl = "";
    private String pageUrl = "";
    private String userAgent = "";
    private final Handler progressHandler = new Handler(Looper.getMainLooper());

    private final Runnable progressRunnable = new Runnable() {
        @Override public void run() {
            updateSessionAndNotification();
            if (player != null && player.isPlaying()) {
                progressHandler.postDelayed(this, 500);
            }
        }
    };

    private final Player.Listener playerListener = new Player.Listener() {
        @Override public void onIsPlayingChanged(boolean isPlaying) {
            updateSessionAndNotification();
        }

        @Override public void onPlaybackStateChanged(int state) {
            updateSessionAndNotification();
            if (state == Player.STATE_READY && player != null && player.isPlaying()) {
                sendBroadcast(new Intent(ACTION_NATIVE_READY).setPackage(getPackageName()));
            } else if (state == Player.STATE_ENDED) {
                sendBroadcast(new Intent(ACTION_NATIVE_ERROR)
                        .putExtra("reason", "ended")
                        .setPackage(getPackageName()));
            }
        }

        @Override public void onPlayerError(PlaybackException error) {
            // Native playback failed: leave the WebView fallback running.
            sendBroadcast(new Intent(ACTION_NATIVE_ERROR)
                    .putExtra("reason", error.getErrorCodeName())
                    .setPackage(getPackageName()));
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannelIfNeeded();

        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true);

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory))
                .build();
        player.addListener(playerListener);

        mediaSession = new MediaSessionCompat(this, "SDKMusicSession");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() {
                if (player != null) {
                    player.play();
                    updateSessionAndNotification();
                }
            }

            @Override public void onPause() {
                if (player != null) {
                    player.pause();
                    updateSessionAndNotification();
                }
            }

            @Override public void onStop() {
                stopPlayback();
            }

            @Override public void onSeekTo(long pos) {
                if (player != null) {
                    player.seekTo(pos);
                    updateSessionAndNotification();
                }
            }
        });
        mediaSession.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // Always handle the foreground-service requirement immediately.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, buildNotification());
        }

        if (intent == null) return START_STICKY;

        String action = intent.getAction();
        if (ACTION_PLAY_URL.equals(action)) {
            String url = intent.getStringExtra("url");
            String title = intent.getStringExtra("title");
            pageUrl = intent.getStringExtra("pageUrl");
            userAgent = intent.getStringExtra("userAgent");

            if (url != null && !url.isEmpty()) {
                currentTitle = title == null || title.isEmpty() ? "SDK Music" : title;
                currentUrl = url;
                playUrl(url);
            }
        } else if (ACTION_PAUSE.equals(action)) {
            if (player != null) player.pause();
            updateSessionAndNotification();
        } else if (ACTION_RESUME.equals(action)) {
            if (player != null) player.play();
            updateSessionAndNotification();
        } else if (ACTION_STOP.equals(action)) {
            stopPlayback();
        }

        return START_STICKY;
    }

    private void playUrl(String url) {
        progressHandler.removeCallbacks(progressRunnable);

        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true);

        if (userAgent != null && !userAgent.isEmpty()) {
            httpFactory.setUserAgent(userAgent);
        }
        if (pageUrl != null && !pageUrl.isEmpty()) {
            httpFactory.setDefaultRequestProperties(
                    java.util.Collections.singletonMap("Referer", pageUrl));
        }

        // Rebuild the player with request headers for hosts that require a
        // browser-like User-Agent/Referer.
        if (player != null) {
            player.removeListener(playerListener);
            player.release();
        }

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory))
                .build();
        player.addListener(playerListener);

        MediaItem item = MediaItem.fromUri(url);
        player.setMediaItem(item);
        player.prepare();
        player.play();

        mediaSession.setActive(true);
        updateSessionAndNotification();
        progressHandler.post(progressRunnable);
    }

    private void updateSessionAndNotification() {
        if (mediaSession == null || player == null) return;

        int state;
        if (player.getPlaybackState() == Player.STATE_ENDED) {
            state = PlaybackStateCompat.STATE_NONE;
        } else if (player.isPlaying()) {
            state = PlaybackStateCompat.STATE_PLAYING;
        } else if (player.getPlaybackState() == Player.STATE_BUFFERING) {
            state = PlaybackStateCompat.STATE_BUFFERING;
        } else {
            state = PlaybackStateCompat.STATE_PAUSED;
        }

        long position = Math.max(0, player.getCurrentPosition());
        long duration = player.getDuration();
        if (duration == C.TIME_UNSET || duration < 0) duration = 0;

        long actions = PlaybackStateCompat.ACTION_PLAY
                | PlaybackStateCompat.ACTION_PAUSE
                | PlaybackStateCompat.ACTION_PLAY_PAUSE
                | PlaybackStateCompat.ACTION_SEEK_TO
                | PlaybackStateCompat.ACTION_STOP;

        PlaybackStateCompat stateObj = new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, position,
                        player.getPlaybackParameters().speed)
                .build();

        mediaSession.setPlaybackState(stateObj);

        MediaMetadataCompat metadata = new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, currentTitle)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "SDK Music")
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, duration)
                .build();
        mediaSession.setMetadata(metadata);

        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIF_ID, buildNotification());
        }

        progressHandler.removeCallbacks(progressRunnable);
        if (player.isPlaying() || state == PlaybackStateCompat.STATE_BUFFERING) {
            progressHandler.postDelayed(progressRunnable, 500);
        }
    }

    private Notification buildNotification() {
        Intent openApp = new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        boolean playing = player != null && player.isPlaying();

        Intent playPause = new Intent(this, MusicService.class)
                .setAction(playing ? ACTION_PAUSE : ACTION_RESUME);
        PendingIntent playPausePending = PendingIntent.getService(
                this, 1, playPause,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, MusicService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        int icon = playing
                ? android.R.drawable.ic_media_pause
                : android.R.drawable.ic_media_play;

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(currentTitle)
                .setContentText("SDK Music")
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .addAction(icon, playing ? "Pause" : "Play", playPausePending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel,
                        "Stop", stopPending)
                .setStyle(new MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void stopPlayback() {
        progressHandler.removeCallbacks(progressRunnable);
        if (player != null) {
            player.stop();
            player.clearMediaItems();
        }
        if (mediaSession != null) mediaSession.setActive(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "Music playback",
                        NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("SDK Music background playback controls");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Keep playback alive when the user swipes the Activity away from recents.
        if (player != null && player.isPlaying()) {
            startForegroundIfNeeded();
        }
        super.onTaskRemoved(rootIntent);
    }

    private void startForegroundIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, buildNotification());
        }
    }

    @Override public void onDestroy() {
        progressHandler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.removeListener(playerListener);
            player.release();
            player = null;
        }
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    public static void play(Context ctx, String url, String title,
                            String pageUrl, String userAgent) {
        Intent i = new Intent(ctx, MusicService.class)
                .setAction(ACTION_PLAY_URL)
                .putExtra("url", url)
                .putExtra("title", title)
                .putExtra("pageUrl", pageUrl)
                .putExtra("userAgent", userAgent);
        androidx.core.content.ContextCompat.startForegroundService(ctx, i);
    }

    public static void pause(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_PAUSE));
    }

    public static void resume(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_RESUME));
    }

    public static void stop(Context ctx) {
        ctx.startService(new Intent(ctx, MusicService.class).setAction(ACTION_STOP));
    }
}
