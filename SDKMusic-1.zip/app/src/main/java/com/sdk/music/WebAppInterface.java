package com.sdk.music;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

public class WebAppInterface {
    public interface Listener {
        void onPlay(String title, String url, double duration, double position);
        void onPause();
        void onEnded();
        void onProgress(double duration, double position);
    }

    private final Listener listener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public WebAppInterface(Listener listener) { this.listener = listener; }

    @JavascriptInterface
    public void onAudioPlay(final String title, final String url, final double duration, final double position) {
        mainHandler.post(() -> listener.onPlay(title, url, duration, position));
    }

    @JavascriptInterface public void onAudioPause() {
        mainHandler.post(listener::onPause);
    }

    @JavascriptInterface public void onAudioEnded() {
        mainHandler.post(listener::onEnded);
    }

    @JavascriptInterface
    public void onAudioProgress(final double duration, final double position) {
        mainHandler.post(() -> listener.onProgress(duration, position));
    }
}
